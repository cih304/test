//<![CDATA[
var	LAYOUT_SPEED	= 400;
var	LAYOUT_TIMEOUT	= undefined;

$(function() {
	$('#header > div.lnb > ul > li > a').bind("mouseover", function() {
		if(LAYOUT_TIMEOUT) {
			clearTimeout(LAYOUT_TIMEOUT);
			LAYOUT_TIMEOUT	= undefined;
		}
		
		var	left	= 0;
		var	rect	= getBounds(this);
		
		if(170 < rect.width) left	= (170 - rect.width) / 2;
		else left	= (rect.width - 170) / 2;
		
		$('#header > div.pop_sitemap > ul').hide();
		$('#subMenu_' + $(this).parent().attr("menuId")).slideDown(LAYOUT_SPEED);
		$('#header > div.pop_sitemap').css("left", (left + rect.left) + "px").slideDown();
	}).bind("mouseout", function() {
		if(LAYOUT_TIMEOUT)
			clearTimeout(LAYOUT_TIMEOUT);

		LAYOUT_TIMEOUT	= setTimeout(closeSiteMap, LAYOUT_SPEED);
	});
	
	$('#header > div.pop_sitemap').bind("mouseover", function() {
		if(LAYOUT_TIMEOUT) {
			clearTimeout(LAYOUT_TIMEOUT);
			LAYOUT_TIMEOUT	= undefined;
		}
	}).bind("mouseout", function() {
		LAYOUT_TIMEOUT	= setTimeout(closeSiteMap, LAYOUT_SPEED / 2);
	});
	
	$('#close_pop_sitemap').click(closeSiteMap);
});

function closeSiteMap() {
	$('#header > div.pop_sitemap').slideUp();
	$('#header > div.pop_sitemap > ul').slideUp(LAYOUT_SPEED);
}
//]]>