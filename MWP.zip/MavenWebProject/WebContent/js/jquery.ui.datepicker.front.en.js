jQuery(function($){
	$.datepicker.regional['en'] = {
			dateFormat: 'yy-mm-dd',
			showOn: "button",
			buttonText: "Calendar",
			buttonImage: "/images/ko/common/calendar.gif",
			buttonImageOnly: true
	};
	$.datepicker.setDefaults($.datepicker.regional['en']);
});