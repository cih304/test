// AF 관련 각종 설정값
var AF_vars = {
	key:'',
	names:'',
	autoForm:'',		// 자동서브밋 폼 이름
	modifyFields:'',	// 수정된 필드
	passFields:'',		// 검사하지 않을 필드 지정, 예) AF_vars.passFields = 'title,contents,userid'
	errMsg:''			// 에러 메세지
};

var AF_util = {
	frm:null,
	field:null,
	types:null,
	msg:null,
	splitText:', ',
	chk:new Array(),
	showError:true,

	// ** 초기화
	init:function(val1, val2){ // init('폼이름'|폼객체[,'필드명'|필드객체])
		this.frm = AF_util.getForm(val1);
		if(this.frm == null)return;
		if(val2 != null){
			this.setField(val2);
			if(this.field == null)return;
		}
	},

	// * 필드 값 얻기
	getValue:function(val){ // getValue('필드명'|필드객체)
		var values = '';
		if(val != null)this.setField(val);
		if(this.field == null)return null;
		this.getType();
		if(this.field.length > 0 && this.types != 'select-one'){
			for(var i=0 ; i<this.field.length ;i++){
				if(this.types == 'radio' || this.types == 'checkbox'){
					if(this.field[i].checked){
						values += this.field[i].value + this.splitText;
					}
				}else{
					values += this.field[i].value + this.splitText;
				}
			}
			var reg = eval('/'+ this.splitText +'$/g');
			values = values.replace(reg, '');
		}else{
			if(this.types == 'radio' || this.types == 'checkbox'){
				if(this.field.checked)values = this.field.value;
			}else{
				if(this.types == 'select-one'){
					values = this.field.options[this.field.selectedIndex].getAttribute('value');
					if(values == null)values = ''; // option 에 value 가 없을때 null 을 공백으로 변환 후 반환
				}else{
					values = this.field.value;
				}
			}
		}
		return values;
	},

	// * 다중 필드 값 얻기
	getValues:function(val){ // getValues('필드1,필드2,필드3, ...') - 배열로 반환
		var tmp = '';
		var aTmp = new Array();
		var aVal = val.replace(/( )*,( )*/g, ',').split(',');
		for(var i=0 ; i<aVal.length ; i++){
			tmp = this.getValue(aVal[i]);
			if(tmp != '')aTmp.push(tmp);
		}
		return aTmp;
	},

	// * 필드 오브젝트 얻기
	getObject:function(sField){ // getObject('필드명'|필드객체)
		if(sField != null)this.setField(sField);
		return this.field;
	},

	// * 필드 타입 얻기
	getType:function(sField){ // getType('필드명'|필드객체)
		if(sField != null)this.setField(sField);
		if(this.field.length > 1 && this.field.type != 'select-one'){
			this.types = this.field[0].type;
			return this.types;
		}
		else{
			this.types = this.field.type;
			return this.types;
		}
	},

	// * 필드 지정
	setField:function(val){ // setField('필드명'|필드객체)
		if(typeof val == 'string'){
			this.field = this.frm.elements[val];

			if(val.match(/.+\[[0-9]+\]$/gi)){ // 배열형 필드이름 처리 - 예) formname[0]
				var names  = val.replace(/\[[0-9]+\]$/gi, '');
				var indexs = val.replace(/^.+\[|]$/gi, '');

				if(this.frm.elements[names].length > 0 && this.frm.elements[names].type != 'select-one'){
					this.field = this.frm.elements[names][indexs];
				}else{ // 필드가 하나라면 ..[0]을 일반 필드로 처리함..
					this.field = this.frm.elements[names];
				}
			}
		}else if(typeof val == 'object'){
			this.field = val;
		}

		if(typeof this.field != 'object'){
			this.field = null;
			if(this.showError){
				alert('AF_util.setField : 지정한 [ ' + val + ' ] 필드가 없습니다');
				this.field		= null;
				this.showError	= true;
			}
		}
	},

	// * 필드 갯수 얻기, f = field
	//	같은 이름의 필드가 몇개 존재하는지 파악한다.
	getCount:function(f){ // getCount('필드명'|필드객체)
		if(f != null)this.setField(f);
		if(this.field.length > 1 && this.field.type != 'select-one'){
			return this.field.length;
		}
		else{
			return 1;
		}
	},

	// * 같은 이름의 필드일때 순서(index) 얻기, 0 부터 시작
	//	얻고자 하는 필드객체를 보내야 한다.
	getIndex:function(f){ // getIndex(필드객체)
		var tmpObj = this.getObject(f);
		this.setField(f.name);
		var cnt = this.getCount();

		if(cnt == 1){
			return 0;
		}else{
			for(var i=0 ; i<cnt ; i++){
				if(this.field[i] == tmpObj){
					return i;
				}
			}
		}
	},


	// * 콤보박스 옵션지우기
	comboClear:function(n){ // comboClear([숫자]), comboClear([-1])
		var tmp = this.field.options.length;
		if(typeof n == 'number')tmp = tmp + n;
		for(var i=0 ; i<tmp ; i++)this.field.remove(this.field.options.length-1);
		this.field.selectedIndex = 0;
	},

	// * 콤보박스 옵션추가
	comboAdd:function(sVal, sText, sSelect){ // comboAdd('값','텍스트'[,'선택될값'])
		var option   = new Option();
		option.value = sVal;
		option.text  = sText;

		if(sSelect != null){
			if(sVal == sSelect)option.selected = true;
		}
		this.field.options.add(option);
	},

	// * 체크 필드 전체 선택
	checkAll:function(bool, val){ // checkAll(true|false[,'필드명'|필드객체])
		try{
			if(val != null){
				this.setField(val);
			}
			var tmp = this.getLen();

			if(tmp == 0){
				this.field.checked = bool;
			}else{
				for(var i=0; i<tmp ; i++){
					this.field[i].checked = bool;
				}
			}
		}catch(e){}
	},

	// * 셀렉트 필드 전체 선택 (멀티셀렉트)
	selectAll:function(bool, val){ // selectAll(true|false[, '필드명'|필드객체])
		try{
			if(val != null){
				this.setField(val);
			}

			var tmp = this.getLen();
			for(var i=0; i<tmp ; i++){
				this.field[i].selected = bool;
			}
		}catch(e){}
	},

	// * 체크박스 선택 수 세기
	checkCnt:function(bool, val){ // checkCnt(true|false[,'필드명'|필드객체])
		if(val != null){
			this.setField(val);
		}

		var cnt = 0;
		var tmp = this.getLen();

		if(tmp == 0){
			if(this.field.checked == bool)cnt++;
		}else{
			for(var i=0; i<tmp ; i++){
				if(this.field[i].checked == bool)cnt++;
			}
		}
		return cnt;
	},

	// * 폼 객체 얻기
	getForm:function(val){ // getForm('폼이름'|폼객체)
		var tmp;

		if(typeof val == 'string'){
			tmp = document.forms[val];
		}else if(typeof val == 'object'){
			tmp = val;
		}

		if(typeof tmp == 'object' && tmp.tagName == 'FORM'){
			return tmp;
		}else{
			alert('AF_util.getForm : 지정한 form 이 없습니다');
			return null;
		}
	},

	// * 특정 문자열을 AF 처리가 가능하게 변환 ..
	getEval:function(val){
		var tmp = val;
		tmp = tmp.replace(/{{([a-z0-9_\[\]]+)}}\s*\=([^=])/gi, "AF_util.getObject('$1').value=$2");	// {{필드명}}= : 해당 필드에 값 넣기
		tmp = tmp.replace(/{{([a-z0-9_\[\]]+)}}/gi, "AF_util.getValue('$1')");						// {{필드명}}  : 해당 필드의 값 얻기
		tmp = tmp.replace(/{([a-z0-9_\[\]]+)}/gi, "AF_util.getObject('$1')");						// {필드명}    : 해당 필드의 객체 얻기
		tmp = tmp.replace(/this\./gi, 'obj.');														// this.       : this 처리
		return tmp;
	},

	getLen:function(){ // 필드 길이 얻기
		if(this.field.length > 0)return this.field.length;
		else return 0;
	},

	getCharLen:function(val, mode){ // 글자수 확인
		var ch = '';
		var bytes = 0;

		for (var i=0; i<val.length; i++){
			ch = val.charAt(i);

			if(mode == 'han' && escape(ch).length > 4){
				bytes += 2;
			}else if (ch == '\n'){
				bytes += 1;
				if(val.charAt(i-1) != '\r'){
					bytes += 1;
				}
			}else{
				bytes += 1;
			}
		}
		return bytes;
	},

	haveBlank:function(sVal){ // 공백 존재 확인
		var tmp = sVal;
		if(tmp.match(/ |　/g))return true;
		else return false;
	},

	removeHan:function(sVal){ // 한글 제거
		return sVal.replace(/[ㄱ-힣]| /g, '');
	},
	removeEng:function(sVal){ // 영문 제거
		return sVal.replace(/[a-z]| /gi, '');
	},
	removeBlank:function(sVal){ // 공백, 특수문자공백, 줄바꿈제거
		return sVal.replace(/\s/g, '');
	},

	isEmpty:function(sVal){ // 값이 비어있나 확인
		var tmp = this.removeBlank(sVal);
		if(tmp == '')return true;
		else return false;
	},
	isNum:function(sVal){ // 숫자 여부
		var tmp = sVal.replace(/[0-9]/g, '');
		if(tmp == '')return true;
		else return false;
	},
	isHan:function(sVal){ // 한글 여부
		var tmp = this.removeHan(sVal);
		if(tmp == '')return true;
		else return false;
	},
	isEng:function(sVal){ // 영문 여부
		var tmp = this.removeEng(sVal);
		if(tmp == '')return true;
		else return false;
	}
};


function AF_srch_key(srch){
	var tmp = eval('/' + srch + '/gi');
	if(srch == '' && AF_util.chk[0] == ''){
		return true;
	}else if(srch != ''){
		for(var i=0 ; i<AF_util.chk.length; i++){
			if(AF_util.chk[i].replace(/ /g,'').match(tmp)){
				AF_vars.key = AF_util.chk[i];
				return true;
				break;
			}
		}
	}
	return false;
}


function AF_set_chkArr(vals){
	if(!vals.match(/\|/g)){
		vals += '|xx';
	}

	var tmp = vals.split('|');
	AF_util.msg = tmp[1];

	if(!tmp[0].match(/,/g)){
		tmp[0] += ',';
	}

	tmp[0] = tmp[0].replace(/,$/g, '');
	AF_util.chk = tmp[0].split(',');
}

// * 폼 체크기																																																															'
function AF_check(targetForm) {
	return AF_check(targetForm, false);
}

function AF_check(targetForm, alertType){ // AF_check(폼객체|'폼이름')
	var frm = AF_util.getForm(targetForm);

	if(frm == null)return false;

	AF_util.init(frm);
	AF_vars.errMsg		= ''; // 에러메세지 초기화

	var check			= true;
	var chk1			= 0;
	var chk2			= 0;
	var chkString		= '';
	var focusElements	= '';
	var isContinue		= true;
	var isOk			= 'Y';
	var names			= '';
	var passFields		= ',' + AF_vars.passFields.replace(/ /gi, '') + ',';
	var tmp1			= '';
	var tmp2			= '';
	var tmp3			= '';
	var tmpArr			= new Array();
	var types			= '';
	var values			= '';
	var obj;

	for(var i=0; i<frm.length ; i++){
		focusElements	= '';
		obj				= frm.elements[i];

		if(obj.getAttribute('chk') != null){
			types			= obj.type;
			names			= obj.name;
			values			= AF_util.getValue(obj);
			chkString		= obj.getAttribute('chk');
			AF_vars.names	= names;

			if(passFields != ''){
				if(passFields.indexOf(',' + names + ',') == -1){
					check = true;
				}else{
					check = false;
				}
			}

			// 폼 체크 시작 (chk 속성이 존재하여야 아래 코드들이 실행된다)
			// exec, if 등의 속성만 있고 chk 속성이 없다면 실행되지 않는다.
			if(check){

				// exec
				// 폼 체크시 지정한 스크립트 실행
				// 폼 체크가 시작되었을때 exec 속성의 내용을 제일 먼저 실행한다.
				// exec 속성의 값으로 자바스크립트 명령을 입력하면 실행이 가능하다.
				// 적절한 사용으로 트리거 효과를 구현할 수 있다.
				// 예) exec="{필드명}.value='값'" 등 활용 가능
				tmp1 = obj.getAttribute('exec');
				if(tmp1 != null){
					try{
						var execStr = AF_util.getEval(tmp1);
						eval(execStr);
						values = AF_util.getValue(obj); // exec 로 현재 필드값을 변경할 수 있으므로 갱신한다.
					}catch(e){alert('[AF_check 경고] - exec 구문 에러\n\n\n원본 : ' +  tmp1 + '\n\n변환 : ' + execStr);return false}
				}

				// if
				// 제한 조건 IF 비교 (이 조건에 걸리면 해당 필드는 '필수' 체크 효과)
				// 예) if="{필드명}=='xx'" - if() 안에 들어갈 구문만 써줌
				tmp1 = obj.getAttribute('if');
				if(tmp1 != null){
					try{
						var ifStr = AF_util.getEval(tmp1);
						if(eval(ifStr)){
							chkString = '필수,' + chkString;
						}
					}catch(e){alert('[AF_check 경고] - if 구문 에러\n\n\n원본 : ' +  tmp1 + '\n\n변환 : ' + ifStr);return false}
				}

				// case
				// 제한 조건 비교 - case (if 사용 권장)
				// 이것은 사용하지 않기를 바란다. -_-;
				if(obj.getAttribute('case') != null){
					try{
					tmp3 = obj.getAttribute('case');
						if(tmp3.match(/!=/gi) && !tmp3.match(/==/gi)){

							tmpArr = tmp3.split('!=');
							if(AF_util.getValue(tmpArr[0]) != tmpArr[1] + '')chkString = '필수,' + chkString;
							else if(AF_util.getValue(obj) != ''){chkString = '필수,' + chkString;focusElements=tmpArr[0];isContinue=false;chk2++}

						}else if(tmp3.match(/^.+==.+=.+$/gi) && !tmp3.match(/!=/gi)){

							tmpArr = tmp3.split('==');
							var tmpArr2 = tmpArr[1].split('=');
							if(eval('AF_util.getObject(tmpArr[0]).' + tmpArr2[0]) == eval(tmpArr2[1]))chkString = '필수,' + chkString;
							else if(AF_util.getValue(obj) != ''){chkString = '필수,' + chkString;focusElements=tmpArr[0];isContinue=false;chk2++}

						}else if(tmp3.match(/^.+==.+!=.+$/gi)){

							tmpArr = tmp3.split('==');
							var tmpArr2 = tmpArr[1].split('!=');
							if(eval('AF_util.getObject(tmpArr[0]).' + tmpArr2[0]) != eval(tmpArr2[1]))chkString = '필수,' + chkString;
							else if(AF_util.getValue(obj) != ''){chkString = '필수,' + chkString;focusElements=tmpArr[0];isContinue=false;chk2++}

						}else if(tmp3.match(/=/gi)){

							tmpArr = tmp3.split('=');
							if(AF_util.getValue(tmpArr[0]) == tmpArr[1])chkString = '필수,' + chkString;
							else if(AF_util.getValue(obj) != ''){chkString = '필수,' + chkString;focusElements=tmpArr[0];isContinue=false;chk2++}

						}
					}catch(e){alert(e + tmpArr[0] + ' 없음');isContinue = false;chk2++}
				}

				// func
				// 함수로 값 검증
				// 예) func="functionName(값)" - true, false 를 반환하는 함수를 사용하여 검증
				// 예2) func="functionName({{필드명}})", func="functionName({필드명}.value)"
				tmp1 = obj.getAttribute('func');
				if(tmp1 != null && (AF_srch_key('필수') || !AF_util.isEmpty(values))){
					try{
						chk1++;
						var funcStr = AF_util.getEval(tmp1);
						if(eval(funcStr)){
							chk2++;
						}else{
							isContinue = false;
						}
					}catch(e){alert('[AF_check 경고] - func 구문 에러\n\n\n원본 : ' +  tmp1 + '\n\n변환 : ' + funcStr);return false}
				}

				AF_set_chkArr(chkString);

				if(isContinue && AF_srch_key('')){ // 선택형 (공백 입력만 방지)
					if(types == 'text' || types == 'textarea' || types == 'file'){
						chk1++;
						if(values != '' && AF_util.removeBlank(values) == '')isContinue = false;
						else chk2++;
					}
				}

				// 필수 일때 비교
				if(isContinue && AF_srch_key('필수')){ // 필수
					chk1++;
					if(types == 'text' || types == 'textarea' || types == 'hidden' || types == 'password' || types == 'file'){
						if(!AF_util.isEmpty(values))chk2++;
						else isContinue = false;
					}
					else if(types == 'radio' || types == 'checkbox'){
						if(frm.elements[names].length > 0){
							for(var j=0 ; j<frm.elements[names].length ; j++){
								if(frm.elements[names][j].checked == true){chk2++;break}
							}
						}
						else{
							if(frm.elements[names].checked == true)chk2++;
						}
					}
					else if(types == 'select-one'){
						if(obj.selectedIndex > 0)chk2++;
						else isContinue = false;
					}
				}

				// 정규식 비교
				if(isContinue && AF_srch_key('정규') && values != ''){
					chk1++;
					if(types == 'text' || types == 'textarea' || types == 'hidden' || types == 'password' || types == 'file'){
						if(obj.getAttribute('regexp') != null){
							try{
								tmp1 = eval(obj.getAttribute('regexp'));
							}catch(e){alert('[AF_check 경고]\n\n정규식이 잘못되었습니다\n\n* NAME : ' + names + '\n* TYPE : '+ types +'\n\n정규식 : ' + obj.getAttribute('regexp') + '\n\n→ /정규식/gi');return false;}
							if(values.match(tmp1))chk2++;
							else isContinue = false;
						}
					}
				}
				// 숫자만 허용 일때
				if(isContinue && AF_srch_key('숫자')){ // 숫자
					chk1++;
					if(types == 'text' || types == 'textarea' || types == 'hidden' || types == 'password'){
						if(AF_util.isNum(values))chk2++;
						else isContinue = false;
					}
				}
				// 영문만 허용 일때
				if(isContinue && AF_srch_key('영어|영문|알파벳')){ // 영어, 영문, 알파벳
					chk1++;
					if(types == 'text' || types == 'textarea' || types == 'hidden' || types == 'password'){
						if(AF_util.isEng(values))chk2++;
						else isContinue = false;
					}
				}
				// 공백 포함 불가 일때
				if(isContinue && AF_srch_key('공백|띄어쓰기')){ // 공백
					chk1++;
					if(types == 'text' || types == 'textarea' || types == 'hidden'  || types == 'password'){
						if(!AF_util.haveBlank(values))chk2++;
						else isContinue = false;
					}
				}
				// n 자 이상일때
				if(isContinue && AF_srch_key('[0-9]자이상') && values != ''){ // n자 이상
					chk1++;
					tmp2 = parseInt(AF_util.removeHan(AF_vars.key));
					if(AF_vars.key.match(/한글/g)){
						tmp1 = 'han';
						tmp2 *= 2;
					}
					if(types == 'text' || types == 'textarea' || types == 'hidden' || types == 'password'){
						if(AF_util.getCharLen(values, tmp1) >= tmp2 )chk2++;
						else isContinue = false;
					}
				}
				// n 자 이하일때
				if(isContinue && AF_srch_key('[0-9]자이하') && values != ''){ // n자 이하
					chk1++;
					tmp2 = parseInt(AF_util.removeHan(AF_vars.key));
					if(AF_vars.key.match(/한글/g)){
						tmp1 = 'han';
						tmp2 *= 2;
					}
					if(types == 'text' || types == 'textarea' || types == 'hidden' || types == 'password'){
						if(AF_util.getCharLen(values, tmp1) <= tmp2 )chk2++;
						else isContinue = false;
					}
				}
				// n 자 입력
				if(isContinue && AF_srch_key('[0-9]자로') && values != ''){ // n자 입력
					chk1++;
					tmp2 = parseInt(AF_util.removeHan(AF_vars.key));
					if(AF_vars.key.match(/한글/g)){
						tmp1 = 'han';
						tmp2 *= 2;
					}
					if(types == 'text' || types == 'textarea' || types == 'hidden' || types == 'password'){
						if(AF_util.getCharLen(values, tmp1) == tmp2 )chk2++;
						else isContinue = false;
					}
				}

				// 제한 조건에 걸렸을 경우 처리
				if(chk1 != chk2){
					if(AF_vars.errMsg == ''){
						AF_vars.errMsg = AF_util.msg.replace(/XX/gi,AF_vars.key);
						AF_vars.errMsg = AF_vars.errMsg.replace(/\\n/gi, '\n');
					}

					try {
						if(focusElements == '') obj.focus();
						else frm.elements[focusElements].focus();
					} catch(e) {}

					if(true === alertType) {
						var span = null;
						
						try {
							if(focusElements == '') span = obj.parentNode.getElementsByTagName('span');
							else span = frm.elements[focusElements].parentNode.getElementsByTagName('span');
						} catch(e) {}
						
						if(span[0]) span[0].innerHTML = "<font color='red'>" + AF_vars.errMsg + "</font>";
						else {
							try {
								send(AF_vars.errMsg);
							} catch(e) {
								alert(AF_vars.errMsg);
							}
						}
					}
					else alert(AF_vars.errMsg);

					isOk = 'N';
					break;
				} else {
					if(true === alertType) {
						var span	= null;
	
						try {
							if(focusElements == '') span = obj.parentNode.getElementsByTagName('span');
							else span = frm.elements[focusElements].parentNode.getElementsByTagName('span');
						} catch(e) {}
	
						if(span[0]) span[0].innerHTML = "&nbsp;";
					}
				}
			}
		}
	} // End For

	if(isOk == 'Y') return true;
	else if(isOk == 'N') return false;
}


// * 비교폼 생성																																								'

function AF_formCreate(){
	var rnd = Math.round(Math.random()*100000);
	AF_vars.autoForm = 'autoSubmit_' + rnd;
	document.writeln('<form name="' + AF_vars.autoForm + '" method="get" action="" style="display:none">');
	document.writeln('</form>');
}

// * 비교용 폼 복사
function AF_copyForm(val){ // AF_copyForm('폼이름'|폼객체)
	AF_formCreate();
	var frm		= AF_util.getForm(AF_vars.autoForm);
	var frm2	= AF_util.getForm(val);
	var names	= '';
	var values	= '';
	var types	= '';
	var newElement;

	if(frm2 == null){
		alert('[AF_copyForm 경고]\n\n복사 할 form이 없습니다.');
		return;
	}

	for(var i = 0 ; i<frm2.length ; i++){
		names			= frm2.elements[i].name;
		values			= frm2.elements[i].value;
		types			= frm2.elements[i].type;
		newElement		= document.createElement('textarea');
		newElement.name	= names;

		if(types == 'radio' || types == 'checkbox'){
			if(frm2.elements[i].checked == true)newElement.value = 'true';
			else if(frm2.elements[i].checked == false)newElement.value = 'false';
		}else newElement.value = values;

		frm.appendChild(newElement);
	}
}

// * 바뀐 내용 비교
function AF_formCompare(val){ // AF_formCompare('폼이름'|폼객체)
	var oriForm		= AF_util.getForm(val); // 원본 폼
	var copyForm	= AF_util.getForm(AF_vars.autoForm); // 복사된 폼
	var tmpArr;
	var tmp1		= '';
	var oriName		= '';
	var oriValue	= '';
	var oriType		= '';
	var copyName	= '';
	var copyValue	= '';
	var deleteFieldIdx		= '';
	var errMsg				= '[AF_copyForm 경고]\n\n';
	AF_vars.modifyFields	= '';

	if(oriForm == null){
		alert(errMsg + ' 폼이 있는지 확인해보세요');
		return false;
	}
	else if(copyForm == null){
		if(confirm(errMsg + ' 폼을 복사할 폼이 생성되지 않았어요\n\nAF_copyForm()을 실행했는지 확인!\n\n그냥 진행 할까요?'))return true;
		return false;
	}


	try{
		for(var i=0 ; i<oriForm.length ; i++){
			oriName		= oriForm.elements[i].name;
			oriValue	= oriForm.elements[i].value;
			oriType		= oriForm.elements[i].type;
			copyName	= copyForm.elements[i].name;
			copyValue	= copyForm.elements[i].value;

			if(oriType == 'radio' || oriType == 'checkbox'){
				if(oriForm.elements[i].checked == true)oriValue = 'true';
				else if(oriForm.elements[i].checked == false)oriValue = 'false';
			}

			if(oriType == 'text' || oriType == 'textarea' || oriType == 'radio' || oriType == 'checkbox' || oriType == 'file' || oriType == 'select-one'){
				if(oriValue != copyValue && copyName != 'AF'){
					if(tmp1 != oriName)AF_vars.modifyFields += '|' + oriName;
					tmp1 = oriName;
				}else if(copyName != 'AF')deleteFieldIdx += '|' + i;
			}
		}

		AF_vars.modifyFields			= AF_vars.modifyFields.replace(/^\|/gi, '');
		deleteFieldIdx					= deleteFieldIdx.replace(/^\|/gi, '');
		oriForm.elements['AF'].value	= AF_vars.modifyFields;
		tmpArr = deleteFieldIdx.split('|');

	}catch(e){
		alert(errMsg + 'AF 를 폼에 넣어주세요');
		return false;
	}

	try{
		for(i=0 ; i<tmpArr.length ; i++){
			oriForm.elements[tmpArr[i]].removeAttribute('name');
		}
	}catch(e){}

	return true;
}

// * 폼의 값 없는 필드 '이름' 없애기																																			'

function AF_removeEmptyField(frm){ // AF_removeEmptyField('폼이름'|폼객체)
	AF_util.init(frm);

	for(var i=0 ; i<frm.length; i++){
		if(frm.elements[i].name != ''){
			if(AF_util.getValue(frm.elements[i]) == ''){
				frm.elements[i].removeAttribute('name');
			}
		}
	}
}