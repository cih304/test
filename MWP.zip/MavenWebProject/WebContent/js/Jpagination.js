/*- =======================================================================
 * Copyright(c) 2009
 * File Description	: pagination js.
 * Author			: jgmik
 * Modified Date	: 2009. 10. 12.
 * Modified Content	:
======================================================================= */
function JPagination(){
	this.pages;
	this.screens;
	this.curScreen;

	this.spage;
	this.epage;

	this.totalRow;
	this.countPerPage;
	this.pagePerScreen;
	this.curPage;
	this.method;
	this.LeftImgPath;
	this.RightImgPath;
	this.firstImgPath;
	this.lastImgPath;
	this.parentDiv;
}
JPagination.prototype.init = function(	layer,
										countPerPage,
										pagePerScreen,
										method,
										firstImgPath,
										LeftImgPath,
										RightImgPath,
										lastImgPath		){

	this.countPerPage =countPerPage;
	this.pagePerScreen =pagePerScreen;

	this.method =method;
	this.LeftImgPath =LeftImgPath;
	this.RightImgPath =RightImgPath;
	this.firstImgPath = firstImgPath;
	this.lastImgPath =lastImgPath;
	this.parentDiv = layer;

}
JPagination.prototype.set = function(	countPerPage,
										totalRow,
										curPage){

	this.countPerPage = Number(countPerPage);
	this.totalRow = totalRow;
	this.curPage = Number(curPage);
	this.show();
}
JPagination.prototype.cal =  function(){
	if(this.curPage <= this.pagePerScreen){
		this.curScreen = 1;
	}else{
		if(this.curPage%this.pagePerScreen==0){
			this.curScreen =Math.floor(this.curPage/this.pagePerScreen);
		}else{
			this.curScreen =Math.floor(this.curPage/this.pagePerScreen)+1;
		}
	}
	if(this.totalRow%this.countPerPage==0){
		this.pages = Math.floor(this.totalRow/this.countPerPage);
	}else{
		this.pages = Math.floor(this.totalRow/this.countPerPage)+1;
	}

	if(	this.pages%this.pagePerScreen==0){
		this.screens = Math.floor(this.pages/this.pagePerScreen);
	}else{
		this.screens = Math.floor(this.pages/this.pagePerScreen+1);
	}
	this.spage = this.curScreen==1?1:(this.curScreen-1)*this.pagePerScreen+1;
	this.epage=0;


	if(this.screens==this.curScreen){
		this.epage=this.pages;
	}else{
		this.epage = this.curScreen*this.pagePerScreen;
	}
}
JPagination.prototype.show = function(){
	this.cal();
	var pageStr = '';
	if(this.totalRow <= 0){
		document.getElementById(this.parentDiv).innerHTML =
			"<div class='pagging'>"+
//			"<a class=\"first  paginate_disabled\">처음</a>"+
			"<a class=\"btn-prev\">"+
			"<img src=\"/images/ko/common/btn_pagging_prev.gif\" border=\"0\" alt=\"이전 10 페이지\" align=\"absmiddle\">"+
			"</a>"+
			"<strong>1</strong>"+
			"<a class=\"btn-next\">"+
			"<img src=\"/images/ko/common/btn_pagging_next.gif\" border=\"0\" alt=\"다음 10 페이지\" align=\"absmiddle\">"+
			"</a>"+
//			"<a class=\"last \">끝</a>"+
			"</div>";
		return;
	}
	pageStr+="<div class='pagging'>";
	if(this.curPage>1){
//		pageStr+= "<a href=\"javascript:"+this.method+"('1')\" class='btn-prev'>"+this.getPPImage()+"</a>";
	}else{
//		pageStr+= "<a class='btn-prev'>"+this.getPPImage()+"</a>";
	}
	if(this.curPage>1){
		if(this.curScreen==1) {
			pageStr+="<a class=\"btn-prev\" href=\"javascript:"+this.method+"('"+1+"')\" >"+this.getPImage()+"</a>";

		} else {
			pageStr+="<a class=\"btn-prev\" href=\"javascript:"+this.method+"('"+((this.curScreen*this.pagePerScreen)-10)+"')\" >"+this.getPImage()+"</a>";

		}
	}else{
		pageStr+="<a class=\"btn-prev\"  >"+this.getPImage()+"</a>";
	}
//	pageStr +="<div style='width:5px;display:block;float:left;'></div>";

	for(var i =this.spage; i<=this.epage; i++){
		//if(i==this.curPage)	pageStr+="<strong class=\"current\">"+i+"</strong>";
		if(i==this.curPage)	pageStr+="<strong>"+i+"</strong>";
		else pageStr+="<a href=\"javascript:"+this.method+"('"+i+"')\" class='num'>"+i+"</a>&nbsp;";
//		if(i != this.epage)
//			pageStr += "";
	}
	

	if(this.curPage!=this.pages){
		if(this.curPage%this.countPerPage==0) {
			pageStr+="<a class=\"btn-next\" href=\"javascript:"+this.method+"('"+(this.curPage+1)+"')\">"+this.getNImage()+"</a>";
		} else {
			if((this.curScreen*this.pagePerScreen)+1>this.pages) {
				pageStr+="<a class=\"btn-next\" href=\"javascript:"+this.method+"('"+((this.pages))+"')\">"+this.getNImage()+"</a>";
			} else {
				pageStr+="<a class=\"btn-next\" href=\"javascript:"+this.method+"('"+((this.curScreen*this.pagePerScreen)+1)+"')\">"+this.getNImage()+"</a>";	
			}
		}
		
	}else{
		pageStr+="<a class=\"btn-next\">"+this.getNImage()+"</a>";

	}
	if(this.curPage!=this.pages){
//		pageStr+="<a class=\"last \" href=\"javascript:"+this.method+"('"+(this.pages)+"')\" class='btn-next' >"+this.getNNImage()+"</a>";
	}else{
//		pageStr+="<a class='btn-next'>"+this.getNNImage()+"</a>";
	}
	pageStr+="</div>";	
	
	document.getElementById(this.parentDiv).innerHTML = pageStr;
}
JPagination.prototype.getPPImage = function() {
	return "<img src='/images/" + (false ? "backimg/pgPrevFirst" : "ko/common/btn_pagging_prev") + ".gif' border='0' alt='이전 " + 10 + " 페이지' align='absmiddle' />";
}

JPagination.prototype.getPImage = function() {
	return "<img src=\"/images/ko/common/btn_pagging_prev.gif\" border=\"0\" alt=\"이전 10 페이지\" align=\"absmiddle\">";
}

JPagination.prototype.getNImage  =function () {
	return "<img src=\"/images/ko/common/btn_pagging_next.gif\" border=\"0\" alt=\"다음 10 페이지\" align=\"absmiddle\">";
}

JPagination.prototype.getNNImage  =function () {
	return "<img src='/images/" + (false ? "backimg/pgNextLast" : "ko/common/btn_pagging_next") + ".gif' border='0' alt='다음 " + 10 + " 페이지' align='absmiddle' />";
}