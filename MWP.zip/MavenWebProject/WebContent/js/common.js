//<![CDATA[

// Prototype Util
String.prototype.trim			= function() { return this.replace(/^\s+|\s+$/g, ""); };
String.prototype.ltrim			= function() { return this.replace(/^\s+/, ""); };
String.prototype.rtrim			= function() { return this.replace(/\s+$/, ""); };
String.prototype.numberFormat	= function() { return this.replace(/(\d)(?=(?:\d{3})+(?!\d))/g, '$1,'); };
String.prototype.phoneNumber	= function() { return this.replace(/(^02.{0}|^01\d{1}|\d{3})(\d+)(\d{4})/, "$1-$2-$3"); };
String.prototype.dateFormat		= function() { return this.replace(/(\d{4})(\d+)(\d{2})/, "$1-$2-$3"); };
String.prototype.bytes			= function() {
									var	len	= 0;
									for(var i = 0, cnt = this.length;i < cnt;i++) len += (this.charCodeAt(i) > 128) ? 2 : 1;
									return len;
								  };

// User client browser
var userAgent	= navigator.userAgent.toLowerCase();
var browser 	= {
	msie    : /msie/.test( userAgent ) && !/opera/.test( userAgent ),
	ie9		: /msie 9\./.test(userAgent),
	safari  : /webkit/.test( userAgent ),
	firefox : /mozilla/.test( userAgent ) && !/(compatible|webkit)/.test( userAgent ),
	chrome	: /chrome/.test( userAgent),
	opera   : /opera/.test( userAgent )
};

function setTwoDigit(value) {
	return (10 > parseInt(value) ? "0" : "") + value;
}

function getBounds(tag) {
	var ret = new Object();

	if(tag.getBoundingClientRect) {
		var rect = tag.getBoundingClientRect();
		ret.left = rect.left + (document.documentElement.scrollLeft || document.body.scrollLeft);
		ret.top = rect.top + (document.documentElement.scrollTop || document.body.scrollTop);
		ret.width = rect.right - rect.left;
		ret.height = rect.bottom - rect.top;
	} else {
		var box = document.getBoxObjectFor(tag);
		ret.left = box.x;
		ret.top = box.y;
		ret.width = box.width;
		ret.height = box.height;
	}

	return ret;
}


function setCookie(cName, cValue, cDay) {
	var expire = new Date();
	var cookies = '';
	expire.setDate(expire.getDate() + cDay);
	cookies = cName + '=' + escape(cValue) + ';';
	if(cDay != null) cookies += ';expires=' + expire.toGMTString() + ';';
	document.cookie = cookies;
}

function getCookie(cName) {
	cName = cName + '=';
	var cookieData = document.cookie;
	var start = cookieData.indexOf(cName);
	var cValue = '';
	if(start != -1){
		start += cName.length;
		var end = cookieData.indexOf(';', start);
		if(end == -1)end = cookieData.length;
		cValue = cookieData.substring(start, end);
	}
	return unescape(cValue);
}

function doDownloadTerms(term_seq) {
	top.location.href = "/download/terms/" + term_seq;
}

function doDownloadMember(svr_mem_seq) {
	top.location.href	= "/download/member/" + svr_mem_seq;
}

function getDocumentHeight() {
	if( browser.msie ){ //IE
		var scrollHeight = document.documentElement.scrollHeight;
		var browserHeight = document.documentElement.clientHeight;
		
		return scrollHeight < browserHeight ? browserHeight : scrollHeight;
	} else if ( browser.safari ){ //Chrome || Safari
		return document.body.scrollHeight;
	} else if ( browser.firefox ){ // Firefox || NS
		if(/firefox\/4/.test( userAgent ) || /firefox\/5/.test( userAgent )) {
			var height	= getBounds(document.getElementById("bodyContent")).height;
				height	+= $('#main').length ? parseInt($('#main').css("height")) : 0;
				height	+= parseInt($('#gnb').css("height"));
			return 1300 < height ? height : 1300;
		}

		var bodyHeight = document.body.clientHeight;
		
		return window.innerHeight < bodyHeight ? bodyHeight : window.innerHeight;
	} else if ( browser.opera ){ // Opera
		var bodyHeight = document.body.clientHeight;
		
		return window.innerHeight < bodyHeight ? bodyHeight : window.innerHeight;
	} else
		return 500;
}

function branchOff() {
	$('#alertMessageText').html(arguments[0]);
	
	$('#alertMessageAction').empty();
	for(var i = 1, count = Math.floor(arguments.length);i < count;) {
		var	text	= arguments[i++];
		var	url		= arguments[i++];

		$('#alertMessageAction').append('<a href="#" class="btn b_red"><span>' + text + '</span></a>');

		var	obj	= $('#alertMessageAction > a:last');
		if(!url)
			obj.click(function() { $.unblockUI(); return false; });
		else if(0 == url.indexOf("http"))
			obj.attr("href", url).click(function() { window.open(this.href); $.unblockUI(); return false; });
		else obj.attr("href", url);
	}
	
	$.blockUI({
		message: $('#alertMessage'),
		css: {
			'width': '420px',
			'border': '1px solid #ccc',
			'padding': '0',
			'opacity': '.95',
			'z-index': '90000',
			'left': ($(window).width() - $('#alertMessage').width()) / 2 + 'px',
			'top': (($(window).height() - $('#alertMessage').height()) / 2) - 150 + 'px'
		}
	});
}


function personPop() {
	window.open("/popup/person" ,  '담당자안내' , "width=798,height=800,toolbar=no,location=no, status=no,menubar=no,scrollbars=no");
}


function getFileExtIcon(fileNm){
	var iconNm = "";
	if( fileNm.indexOf(".xlsx") > 0 ){
		iconNm = "iconExcel";
	}else if( fileNm.indexOf(".pptx") > 0 ){
		iconNm = "iconPpt";
	}else if( fileNm.indexOf(".ppt") > 0 ){
		iconNm = "iconPpt";
	}else if( fileNm.indexOf(".docx") > 0 ){
		iconNm = "iconWord";
	}else if( fileNm.indexOf(".doc") > 0 ){
		iconNm = "iconWord";
	}else if( fileNm.indexOf(".gif") > 0 ){
		iconNm = "iconGif";
	}else if( fileNm.indexOf(".jpg") > 0 ){
		iconNm = "iconJpg";
	}else if( fileNm.indexOf(".png") > 0 ){
		iconNm = "iconPng";
	}else if( fileNm.indexOf(".pdf") > 0 ){
		iconNm = "iconPdf";
	}else if( fileNm.indexOf(".hwp") > 0 ){
		iconNm = "iconHwp";
	}else if( fileNm.indexOf(".zip") > 0 ){
		iconNm = "iconZip";
	}else if( fileNm.indexOf(".txt") > 0 ){
		iconNm = "iconTxt";
	}else{
		iconNm = "iconFile";
	}
	
	var iconPath = "/images/frontimg/"+iconNm+".png";
	return iconPath;
}
function fillString( str, number) {
	var result = "";

	for(var i = 0; i < number; i ++) {
		result += str;
	}
	
	return result;
}
function null2str( s,  p)
{
	if (s == null || s.length == 0)
		return null2space(p);
	else
		return s.trim();
}
function null2space(s)
{
	return "";

}

function createHidden(myform,n,v) {	

    var hiddenObj = document.getElementById(n);
    
    //동일한 아이디가 없으면 생성한다.
    if(hiddenObj == null){
     var o=document.createElement("input");
     o.type="hidden";
     o.id=n;
     o.name=n;
     o.value=v;
     myform.insertBefore(o);
    }else{
     hiddenObj.value = v;
    }

   }

//버전 범위 체크
function validationVersion(obj) {
	var val = obj.value;
	if(sdkVersionFormat(val) == false) {
		$(obj).focus();
		return;
	}
}

function sdkVersionFormat(value) {
    var verPattern = /^(\d{1,2})\.(\d{1,2})\.(\d{1,2})$/;
    var verArray = value.match(verPattern);
    
    if(verArray !=null) {
    	for (var i = 0; i < 4; i++) {
            thisSegment = verArray[i];
            if (thisSegment > 99) {
            	alert("입력범위를 초과하였습니다.");
                return false;                
            }
            if ((i == 0) && (thisSegment > 99)) {
            	alert("입력범위를 초과하였습니다.");
                return false;
            }
        }
    } else {
    	alert("버전 정보가 잘못되었습니다.");
		return false;
    }
    return true; 
} 

function idCheck(user_id){
	$.ajax({
      type: "POST",
      url: "./idValidationCheck",
      data: "&user_id=" + user_id, 
      dataType: "json",
      async: false,
      success:function(data) {
    	  if(data.result){
    		  $('#idCheck').val('Y');
    	  }else{
    		  alert("중복된 아이디입니다.\n확인하시고 다른 아이디를 입력해 주세요.");
    		  return false;
    	  }
      },
      fail:function() {
       alert("ID 중복확인에 실패했습니다.");
       return "";
      }
     });
}

function onlyNum(input) {
    var chars = "0123456789"; //입력가능한 문자 지정
    return containsCharsOnly(input, chars);
}

function containsCharsOnly(input, chars) {
    
    for (var inx = 0; inx <= input.value.length; inx++) {

        if (inx == 0) {//최초입력한 문자
            e = window.event;
            if (window.event) {
                key = e.keyCode;
            } else if (e) {
                key = e.which;
            } else {
                return true;
            }
            keychar = String.fromCharCode(key);
            if (chars.indexOf(keychar) == -1)// window.event 에서 받은 keychar 로 유효성 검사.
                return false;
        }
        else {//최초입력 문자가 아니면, input 의 text를 읽어서 처리한다.
            if (chars.indexOf(input.value.charAt(inx)) == -1) {
                return false;
            }
        }
    }
    return true;
}


//]>>