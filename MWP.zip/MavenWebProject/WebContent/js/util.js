//그래프 width, height지정
var GRAPH_WIDTH = "100%";
var GRAPH_HEIGHT = "500";

jQuery(function($){
	
	$.fn.total = function( opt){
		
		var $totalDataRow = $("#" + opt.id).find("tr");
		var $footer = $(this).find("td");
		var total = [];
		
		if($totalDataRow.length > 0)
		{
			if($totalDataRow.find("td").size() > 1){
				$totalDataRow.each(function(i, row){
					
					$(row).find("td").each(function( y, item){
						var value = $(item).text().trim();
						if(value == '') value = '0';
						var num = parseFloat( value.replace(/\,/g, ""));
						
						var chk = false;
						$(opt.exclude).each(function(){
							if(y == this)
								chk = true;
						});
						
						if(!chk)
							total["data" + y] = total["data" + y] ? (total["data" + y] + num) : num ;
						
					});
				});
				
				$footer.each(function( i){
					
					var chk = false;
					$(opt.exclude).each(function(){
						if(i == this)
							chk = true;
					});
					
					if(!chk)
					$(this).text(roundFixed(total["data" + i],5));
				});
			}
		}
	};

	$.fn.avg = function( opt){
		

	};
	
	$.fn.xls = function( opt){
		
		$(this).click(function( e){
			
			$(this).prop("disabled", true);
			
			var $temp = $("<div/>");
			
			$temp.append( $("#" + opt.id).clone());

			$temp.children(":first").prop("border","1");
			
			if($temp.find("textarea").size() > 0){
				$temp.find("textarea").each(function(i,item){
					var tmpText = $(item).text();
					
					$(item).parents("td").text(tmpText);
				});
			}
			//$("body").append($temp);
			
			document.excelForm.tabledata.value = encodeURIComponent($temp.html());
			document.excelForm.xlsname.value = opt.name;
			document.excelForm.target = "hiddenframe";
			
			document.excelForm.submit();
			
			//$temp.remove();
			$(this).prop("disabled", false);
			
		});
		
	};
	
	$.fn.merge = function( opt){
		
		if($(this).find("tr").length < 2) return;
		
		var $target = null;
		var $rows = $(this).find("tr");
		
		$(opt).each(function(i, col){
			
			var temp;
			$rows.each(function( i){
				
				var $cell = $(this).children(":eq(" + col + ")");
				var value = $cell.text().trim();
				
				if(value != '' && temp != value)
				{
					$target = $cell;
					$cell.prop("rowspan", 1);
				}
				else
				{
					$target.prop("rowspan", $target.prop("rowspan") + 1);
					//$cell.hide();
					$cell.remove();
				}
				
				temp = value;
					
			});
			
		});
		

	};
	
	$.fn.chart = function( data){
		
		var $target = $(this);
		
		var $chart = $("<chart />");
		
		if(data.option)
		{
			var option = data.option;
			
			$.each(option, function(key, value){
				$chart.attr( key, value);
			});

		}
		
		if(data.categories)
		{
			var $categories = $("<categories />");
			
			
			var categories = data.categories;

			$(categories).each(function( i, item){	
			  
				$categories.append( "<category name='" + item.name + "' />");
			});
			
			$chart.append($categories);
		}
		
		if(data.dataNames && data.dataset)
		{
			var dataset = data.dataset;
				
			data.dataNames.forEach(function ( name, index, array) {
				
				var $dataset = $("<dataset />");
				
				if(data.lines && data.lines.indexOf(index) > -1)
					$dataset.attr("parentYAxis",'S');

				$dataset.attr("seriesName", name);
				

				$(dataset[index]).each(function(){
					
					$dataset.append("<set value='" + (this ? this : 0 )+ "' />");
				});
				
				$chart.append($dataset);
			});	

		}
		
		//console.log($("<div/>").append($chart).html());
		
		var	chart	= new FusionCharts( data.swfurl, data.id, data.width, data.height);
		chart.setDataXML($("<div/>").append($chart).html());
		chart.setTransparent("transparent");
		chart.render(data.id);
	};
	
});

function doDownload(type, seq, num, name) {
	if(0 >= $('#fileFrame').length)
		$('body').prepend(
			'<iframe id="fileFrame" name="fileFrame" width="1" height="1" style="display:none;"></iframe>' +
			'<form id="fileFrm" method="get" target="fileFrame"><input type="hidden" name="orgFileNm" /><input type="hidden" name="type" /><input type="hidden" name="seq" /><input type="hidden" name="num" /></form>'
			//'<form id="fileFrm" method="post" target="fileFrame"><input type="hidden" name="type" /><input type="hidden" name="seq" /><input type="hidden" name="num" /></form>'
		);
	
	var	fm	= $('#fileFrm')[0];
		fm.type.value	= type;
		fm.num.value	= num;
		fm.seq.value	= seq;
		fm.orgFileNm.value	= name;
		fm.action		= "/download/" + type + "/" + seq + "/" + num;
		fm.submit();
}

function commify(n) {
   var reg = /(^[+-]?\d+)(\d{3})/;   // 정규식
   n += '';                          // 숫자를 문자열로 변환
   
   while (reg.test(n))
     n = n.replace(reg, '$1' + ',' + '$2');
   
   return n;
}

function roundFixed(n, digits) {
	return commify(parseFloat(parseFloat(n).toFixed(digits))); // 소수부 반올림
}
