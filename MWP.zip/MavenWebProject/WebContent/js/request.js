//<![CDATA[
var	focusPort	= undefined;

function searchPop(type, select) {
	window.open("/popup/user?user_type=" + (!type ? "" : type) + "&select_type=" + (!select ? "" : select), "UserSearchPop", "width=710,height=700,status=no,scrollbars=yes");	
}


function removeUser() {
	if(!$('#userListTable > tbody input[type=checkbox]').is(":checked")) {
		alert("선택된 사용자가 없습니다.");
		return;
	}
	
	$('#userListTable > tbody input[type=checkbox]:checked').each(function() {
		$(this).parent().parent().remove();
	});

	if(0 == $('#userListTable > tbody > tr').length)
		$('#userListTable > tbody').append('<tr><td colspan="' + $('#userListTable > thead > tr:first > th').length + '">+++ 사용자를 추가해 주세요 +++</td></tr>');
}

$(function() {
	$('#allchk').click(function() {
		$('#userListTable > tbody input[type=checkbox]').attr("checked", this.checked);
	});
	
	$('#isAttach').click(function() {
		if(this.checked) {
			$('#attachTable').show();
			$('#userListTable').hide();
			$('#userListControl').hide();
		} else {
			$('#attachTable').hide();
			$('#userListTable').show();
			$('#userListControl').show();
		}
	});
});
//]>