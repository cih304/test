/* 2007. 11. 12 - dhseol
*  Tree 구조 로직 변경
*/
var addFlag = true;
var uptFlag = true;
var delFlag = true;
var movFlag = true;
var funcLimitFlag = false;

var oldId = '';
var curId = '';
var CTX_ROOT = "";
var isPopup =false;
var folderType = 1;

function isRoot(fl_id) {
	var rootList = '' + document.fTreeFrm.rootList.value + '|sendbox|unremove|unremove_lts|itsupport|grcntr|soctransfer|grsendbox|';
	var key = '|' + fl_id + '|';
	if (rootList.indexOf(key) >= 0) {
		return true;
	}
	else {
		return false;
	}
}

function getParentId(fl_id) {
	if (isRoot(fl_id) == true) return "";
	
	var obj = document.getElementById('_' + fl_id);
	if (obj != null && obj.parentNode != null && obj.parentNode.parentNode != null) {
		var pId = obj.parentNode.parentNode.id;
		if (pId != null && pId.length > 1)
			return pId.substring(1, pId.length);
	}
	return "";
}

function getDepth(fl_id) {
	var obj = document.getElementById('depth_' + fl_id);
	return obj.innerHTML;
}

function getLtsYn(fl_id) {
	var obj = document.getElementById('lts_yn_' + fl_id);
	if (obj != null)
		return obj.innerHTML;
	else
		return '';
}

function getLogicalFolder(fl_id) {
	var obj = document.getElementById('lf_' + fl_id);
	return obj.innerHTML;
}

function getFolderName(fl_id) {
	var obj = document.getElementById('nm_' + fl_id);
	return obj.innerHTML;
}
function openFolder(fl_id,reloadFlag,type) {
	
	if(reloadFlag || document.getElementById('sub_' + fl_id).innerHTML == "") {
		//hFrame.document.location = CTX_ROOT + '/usr/folder/folderTree.open.jsp?fl_id=' + fl_id;
		subList(fl_id,type);	//jgmik
		/*
		document.fTreeFrm.fl_id.value = fl_id;
		document.fTreeFrm.target = "hFrame";
		document.fTreeFrm.action = CTX_ROOT + "/usr/folder/folderTree.open.jsp";
		document.fTreeFrm.submit();
		*/
	}
	document.getElementById('sub_' + fl_id).style.display = '';
	document.getElementById('node_' + fl_id).src = CTX_ROOT + '/images/frontimg/ico_minus.png';
	document.getElementById('node_' + fl_id).name = 'ico_minus.png';
}
function openRootFolder(fl_id,reloadFlag,type) {	//jgmik
	if(reloadFlag || document.getElementById('sub_' + fl_id).innerHTML == "") {
		//hFrame.document.location = CTX_ROOT + '/usr/folder/folderTree.open.jsp?fl_id=' + fl_id;
		subList(fl_id,type);	//jgmik
		/*
		document.fTreeFrm.fl_id.value = fl_id;
		document.fTreeFrm.target = "hFrame";
		document.fTreeFrm.action = CTX_ROOT + "/usr/folder/folderTree.open.jsp";
		document.fTreeFrm.submit();
		*/
	}
	document.getElementById('sub_' + fl_id).style.display = '';
}
function closeFolder(fl_id) {
	document.getElementById('sub_' + fl_id).style.display = 'none';
	document.getElementById('node_' + fl_id).src = CTX_ROOT + '/images/frontimg/ico_plus.png';
	document.getElementById('node_' + fl_id).name = 'ico_plus.png';
}

function getNode(fl_id,type) {	

	var node = document.getElementById('node_' + fl_id).name;

	if(node == 'ico_plus.png')
		openFolder(fl_id,false,type);
	else if(node == 'ico_minus.png')
		closeFolder(fl_id);
}

function selectFolderPopup(fl_id,reloadFlag) {
	
	if(oldId != '' && document.getElementById('folder_' + oldId) != null) {
		document.getElementById('folder_' + oldId).style.fontWeight = '';
		document.getElementById('folder_' + oldId).style.backgroundColor = '#FFFFFF';
		document.getElementById('color_' + oldId).style.color = '';
		//document.getElementById('img_' + oldId).src = CTX_ROOT + '/img/ico_08.gif';
	}	
	document.getElementById('folder_' + fl_id).style.fontWeight = 'bold';
	document.getElementById('folder_' + fl_id).style.backgroundColor = '';
	document.getElementById('color_' + fl_id).style.color = '#FF6633';
	//document.getElementById('img_' + fl_id).src = CTX_ROOT + '/img/ico_09.gif';
	
	if (isRoot(fl_id) == false && ( document.getElementById('node_' + fl_id).name == 'ico_plus.png' || reloadFlag ) ) {
		openFolder(fl_id , reloadFlag );
	}else if( isRoot( fl_id ) ){					//jgmik
		openRootFolder(fl_id , reloadFlag );	//jgmik
	}
	
	oldId = fl_id;	
	curId = fl_id;

	var logical_folder = getLogicalFolder(fl_id);

	if (isRoot(fl_id)) {
		uptFlag = false;
		delFlag = false;
		movFlag = false;
		
		if (logical_folder == 'D' || logical_folder == 'L' || logical_folder == 'N') addFlag = true;
		else addFlag = false;
	}
	else {
		addFlag = true;
		uptFlag = true;
		delFlag = true;
		movFlag = true;
	}

	// 파일보관함 하위 폴더이고, 사용자가 유효한 파일보관관권한이 없을때
	funcLimitFlag = false;
	if (getLtsYn(fl_id) == 'Y') {
		if (document.fTreeFrm.user_lts_yn.value != 'Y' ||
			document.fTreeFrm.org_id.value != document.fTreeFrm.lts_org_id.value) {
			funcLimitFlag = true;
		}
	}
}
function selectFolder(fl_id,reloadFlag,type) {
	document.getElementById('color_sendBox').style.color = '';
	if(oldId != '' && document.getElementById('folder_' + oldId) != null) {
		document.getElementById('folder_' + oldId).style.fontWeight = '';
		document.getElementById('folder_' + oldId).style.backgroundColor = '#FFFFFF';
		document.getElementById('color_' + oldId).style.color = '';
		//document.getElementById('img_' + oldId).src = CTX_ROOT + '/img/ico_08.gif';
	}	
	document.getElementById('folder_' + fl_id).style.fontWeight = 'bold';
	document.getElementById('folder_' + fl_id).style.backgroundColor = '';
	document.getElementById('color_' + fl_id).style.color = '#FF6633';
	//document.getElementById('img_' + fl_id).src = CTX_ROOT + '/img/ico_09.gif';
	if(type != 3 && type != 4){//발신함
		if (isRoot(fl_id) == false && ( document.getElementById('node_' + fl_id).name == 'ico_plus.png' || reloadFlag ) ) {
			openFolder(fl_id , reloadFlag,type );
		}else if( isRoot( fl_id ) ){					//jgmik
			openRootFolder(fl_id , reloadFlag, type );	//jgmik
		}
		if(reloadFlag){
			setMainCount();
		}
	}
	oldId = fl_id;	
	curId = fl_id;

	if(type==3 || type==4 ){//발신함
		return;
	}
	
	folderType = type;
	var logical_folder = getLogicalFolder(fl_id);

	if (isRoot(fl_id)) {
		uptFlag = false;
		delFlag = false;
		movFlag = false;
		if (logical_folder == 'D' || logical_folder == 'L' || logical_folder == 'N') addFlag = true;
		else addFlag = false;
	}
	else {
		addFlag = true;
		uptFlag = true;
		delFlag = true;
		movFlag = true;
	}

	// 파일보관함 하위 폴더이고, 사용자가 유효한 파일보관관권한이 없을때
	funcLimitFlag = false;
	if (getLtsYn(fl_id) == 'Y') {
		if (document.fTreeFrm.user_lts_yn.value != 'Y' ||
			document.fTreeFrm.org_id.value != document.fTreeFrm.lts_org_id.value) {
			funcLimitFlag = true;
		}
	}
	SEARCH_CURPAGE = 1;
	getUserFile(fl_id);

	/*
	if (fl_id == 'sendbox') {
		selectSendBox();
	}
	else if (fl_id == 'unremove') {
		selectUnRemove('N');
	}
	else if (fl_id == 'unremove_lts') {
		selectUnRemove('Y');
	}	
	else if (fl_id == 'itsupport') {
		selectItsSupport();
	}
	else if(fl_id == 'grcntr') {
		selectGrCntr();
	}
	else if(fl_id == 'soctransfer') {
		selectSocTransfer();
	}
	else if(fl_id == 'grsendbox') {
		selectGrSendBox();
	}
	else if (document.getElementById('moveYn').value != 'Y'){	// 이동이 아닐경우
		mainFrameDetail(fl_id);
	}
	else if (document.getElementById('selOwnCtrl').value == 'Y'){	// 자체처리
		selectOwnCtrl(fl_id);
	}
	*/
}
function refreshFolder(refreshList, last_id) {
	var rList = refreshList.split(',');
	
	document.fTreeFrm.refreshList.value = refreshList;
	document.fTreeFrm.fl_id.value       = last_id;
	document.fTreeFrm.target = "hFrame";
	document.fTreeFrm.action = CTX_ROOT + "/usr/folder/folderTree.refresh.jsp";
	document.fTreeFrm.submit();
}

function refreshDone() {
	document.fTreeFrm.target = "hFrame";
	document.fTreeFrm.action = "about:blank";
	document.fTreeFrm.submit();
}

function addFolder(){
	if (curId == '') {
		alert("폴더를 선택하십시오.");
		return;
	}
	if (addFlag == false) {
		alert("하위 폴더를 추가할 수 없는 폴더입니다.");	
		return;
	}
	else if (funcLimitFlag == true) {
		alert("권한 해지 또는 부서이동에 의해 차단된 기능입니다.");
		return;
	}
	document.fTreeFrm.method = "post";
	document.fTreeFrm.action = "/popup/folderAdd";
	document.fTreeFrm.target = "POP";
	
	document.fTreeFrm.fl_id.value = curId;
	document.fTreeFrm.lts_yn.value = getLtsYn(curId);

	var height = 251;
	if (document.fTreeFrm.lts_yn.value == 'Y') {
		height += 220;
	}
	var popup = window.open("","POP","width=100, height=100,left=100, top=100, scrollbars=yes");
//	POP.focus();
	document.fTreeFrm.submit();
	//popupCenterPOST(CTX_ROOT + '/usr/folder/folderTree.folderAdd.jsp','addfolder','width=401,height=' + height, 'fTreeFrm');
}

function updateFolder(){
	if (curId == '') {
		cdtsAlert("폴더를 선택하십시오.");
		return;
	}
	if (uptFlag == false) {
		cdtsAlert("수정할 수 없는 폴더입니다.");
		return;
	}
	else if (funcLimitFlag == true) {
		cdtsAlert("권한 해지 또는 부서이동에 의해 차단된 기능입니다.");
		return;
	}

	document.fTreeFrm.fl_id.value  = curId;
	document.fTreeFrm.lts_yn.value = getLtsYn(curId);
	
	var height = 251;
	if (document.fTreeFrm.lts_yn.value == 'Y') {
		height += 220;
	}
	popupCenterPOST(CTX_ROOT + '/usr/folder/folderTree.folderModify.jsp','addfolder','width=400,height=' + height, 'fTreeFrm');
}

function moveFolder(){
	if (curId == '') {
		cdtsAlert("폴더를 선택하십시오.");
		return;
	}
	if (movFlag == false) {
		cdtsAlert("이동할 수 없는 폴더입니다.");
		return;
	}
	else if (funcLimitFlag == true) {
		cdtsAlert("권한 해지 또는 부서이동에 의해 차단된 기능입니다.");
		return;
	}

	document.fTreeFrm.fl_id.value = curId;
	document.fTreeFrm.parent_id.value = getParentId(curId);

	popupCenterPOST(CTX_ROOT + '/usr/folder/folderTree.folderMove.jsp','movefolder','width=412,height=437', 'fTreeFrm');
}

function deleteFolder(){
	if (curId == '') {
		cdtsAlert("폴더를 선택하십시오.");
		return;
	}
	if (delFlag == false) {
		cdtsAlert("삭제할 수 없는 폴더입니다.");	
		return;
	}
	else if (funcLimitFlag == true) {
		cdtsAlert("권한 해지 또는 부서이동에 의해 차단된 기능입니다.");
		return;
	}

	document.fTreeFrm.fl_id.value = curId;	
	if(cdtsConfirm("하위 폴더 및 파일들이 같이 삭제됩니다.\n\n폴더를 삭제하시겠습니까?")){
		document.fTreeFrm.target = "hFrame";
		document.fTreeFrm.method = "post";
		document.fTreeFrm.action = CTX_ROOT + "/usr/folder/folderTree.delete.jsp";
		document.fTreeFrm.submit();
	}else{
	    return;
	}    
}

function deleteFolderDone(result, retmsg, delete_id) {
	if (result == true) {
		cdtsAlert('폴더가 삭제되었습니다.');
		var parent_id = getParentId(delete_id);
		refreshFolder(parent_id, parent_id);
	}
	else {
		cdtsAlert(retmsg);
		document.fTreeFrm.target = "hFrame";
		document.fTreeFrm.method = "post";
		document.fTreeFrm.action = "about:blank";
		document.fTreeFrm.submit();
	}
}

// mainFrame 변경...
function mainFrameDetail(fl_id) {	
	var mainUrl = CTX_ROOT + "/usr/file/userFile_jgmik.jsp";

	fTreeFrm.folder_id.value = fl_id;
	fTreeFrm.method = "post";
	fTreeFrm.target = "mainFrame";
	fTreeFrm.action = mainUrl;
	fTreeFrm.submit();
}

function selectSendBox() {
	var mainUrl = CTX_ROOT + "/usr/file/userTransferFile.jsp";
				
	fTreeFrm.method = "post";
	fTreeFrm.target = "mainFrame";
	fTreeFrm.action = mainUrl;
	fTreeFrm.submit();
}
			
// 미파기 문서함 목록을 표시함
function selectUnRemove(lts_yn) {			
	var mainUrl = CTX_ROOT + "/usr/destruct/destructManager.jsp";

	fTreeFrm.lts_yn.value = lts_yn;
	fTreeFrm.method = "post";
	fTreeFrm.target = "mainFrame";
	fTreeFrm.action = mainUrl;
	fTreeFrm.submit();
}

// IT지원요청함 목록을 표시함
function selectItsSupport() {			
	var mainUrl = CTX_ROOT + "/usr/itrm/itrmManager.jsp?localYN=Y";
			
	fTreeFrm.method = "post";
	fTreeFrm.target = "mainFrame";
	fTreeFrm.action = mainUrl;
	fTreeFrm.submit();
}

function selectGrCntr() {
	var mainUrl = CTX_ROOT + "/usr/file/userFile.grReceiveFile.jsp";
			
	fTreeFrm.method = "post";
	fTreeFrm.target = "mainFrame";
	fTreeFrm.action = mainUrl;
	fTreeFrm.submit();
}

function selectSocTransfer() {
	var mainUrl = CTX_ROOT + "/usr/file/userFile.socTransferFile.jsp";
			
	fTreeFrm.method = "post";
	fTreeFrm.target = "mainFrame";
	fTreeFrm.action = mainUrl;
	fTreeFrm.submit();
}
// GR
function selectGrSendBox() {
	var mainUrl = CTX_ROOT + "/usr/file/userFile.grTransferFile.jsp";
			
	fTreeFrm.method = "post";
	fTreeFrm.target = "mainFrame";
	fTreeFrm.action = mainUrl;
	fTreeFrm.submit();
}

// 대리점 관리 화면을 표시함
function selectAgencyManager(id) {	
	setColorSelectedFolder(id);
	
	var mainUrl = CTX_ROOT + "/usr/agency/agencyManager.jsp";
			
	fTreeFrm.method = "post";
	fTreeFrm.target = "mainFrame";
	fTreeFrm.action = mainUrl;
	fTreeFrm.submit();
}

// 외부 사용자 사용 신청 화면을 표시함
function selectUseRequestExternalManager(id) {
	setColorSelectedFolder(id);
	
	var mainUrl = CTX_ROOT + "/usr/request/useRequestManager.jsp";
	
	fTreeFrm.method = "post";
	fTreeFrm.target = "mainFrame";
	fTreeFrm.action = mainUrl;
	fTreeFrm.submit();
}

// 자동결재 기간 설정 요청 화면을 표시함
function selectPassPeriod(id, mode) {
	setColorSelectedFolder(id);
	
	var mainUrl = CTX_ROOT + "/usr/passPeriod/passPeriod.jsp?mode=" + mode;
	
	fTreeFrm.method = "post";
	fTreeFrm.target = "mainFrame";
	fTreeFrm.action = mainUrl;
	fTreeFrm.submit();
}

//	SOC외부전송 권한 신청 화면을 표시함
function selectSoc(id, mode) {
	setColorSelectedFolder(id);
	
	var mainUrl = CTX_ROOT + "/usr/soc/soc.jsp?mode=" + mode;
	
	fTreeFrm.method = "post";
	fTreeFrm.target = "mainFrame";
	fTreeFrm.action = mainUrl;
	fTreeFrm.submit();
}

//	파일보관함 신청 화면을 표시함
function selectFileBox(id, mode) {
	setColorSelectedFolder(id);
	
	var mainUrl = CTX_ROOT + "/usr/filebox/filebox.jsp?mode=" + mode;
	
	fTreeFrm.method = "post";
	fTreeFrm.target = "mainFrame";
	fTreeFrm.action = mainUrl;
	fTreeFrm.submit();
}

//	부승인권자 신청 화면을 표시함
function selectSubAppr(id) {
	setColorSelectedFolder(id);
	
	var mainUrl = CTX_ROOT + "/usr/subAppr/subAppr.jsp";
	
	fTreeFrm.method = "post";
	fTreeFrm.target = "mainFrame";
	fTreeFrm.action = mainUrl;
	fTreeFrm.submit();
}

// 선택된 메뉴의 스타일을 변경함
function setColorSelectedFolder(id){
	if (id){
		var oldNode = document.getElementById(oldId);
		if(oldNode) {
			oldNode.style.fontWeight = '';
			oldNode.style.backgroundColor = '#FFFFFF';
			oldNode.style.color = '';
		}	
		
		var node = document.getElementById(id);
		if(node)
		{
			node.style.fontWeight = 'bold';
			node.style.backgroundColor = '';
			node.style.color = '#FF6633';
			
			oldId = id;	
			curId = id;
		}
	}
}

function removeNode(fl_id){
	$("#_"+fl_id).remove();

}


//jgmik 추가
var PAGE_URL = "";
function getUserView(type,fl_id){
	var url = type==1?"myfolderList":"myreciveList";
	if( PAGE_URL == url ){  
		selectFolder(fl_id,false,type);
		return;
	}
	$.ajax({
		type: "POST",
		url: "/file/"+url,
		data:  "fl_id=" + fl_id,
		dataType: "html",
		async: false,
		success:function(data) {
			$("#containerBside").html(data);
			PAGE_URL = url;
			selectFolder(fl_id,false,type);
		},
		fail:function(e) {
			alert(e);
		},
		error:function(a,b,c){
			if(a.status == 999){
				goUrl('/');
			}
		}
	});
}

function goUrl(url,msg){
	if(msg){
		alert(msg);
	}
	window.location.href = url;
}
function subList(p_fl_id,type){
	$.ajax({
		type: "POST",
		url: "/file/subList",
		data:  "fl_id=" + p_fl_id+"&type="+type,
		dataType: "json",
		async: false,
		success:function(data) {
			var nodeImg   = "";
			var subFolder = "";
			var folderName = data.folderName;
			var subList = data.list;
			for (var i = 0; subList != null && i < subList.length; i++) {

				var subVO = subList[i];
				var fl_id		= subVO.fl_id;
				var fl_name	= subVO.fl_name;
		//		if(fl_id.equals(param.get("move_fl_id"))) continue;
				var sub_cnt 	= subVO.sub_cnt;
				var file_cnt	= subVO.file_cnt;
				var depth		= subVO.depth;
				
				if(sub_cnt > 0) nodeImg = "ico_plus.png";
				else			nodeImg = "ico_minus.png";
				
				var lts_limit_str = "";
				if ("Y" == subVO.lts_yn ) {
//					int lts_limit = Integer.parseInt( subVO.get("lts_limit"));
//					String date_create = DateUtil.toDateFormat(subVO.get("date_create").substring(0, 8), "yyyy-MM-dd");
//					lts_limit_str = DateUtil.toDateFormat( DateUtil.getAfterDate( date_create,  lts_limit ), "yyyy-MM-dd") + "까지" ;
					lts_limit_str = "[<span class=red>" + lts_limit_str + "</span>]";
				}
				var CTX_ROOT = "";
				subFolder += "<div id=\"_" + fl_id + "\" nowrap>" 
						  + "<table border=\"0\" cellspacing=\"0\" cellpadding=\"0\" height=\"20\">"
						  +"<tr><td>"
				          + fillString("　", depth) + "<img id=\"node_" + fl_id + "\" src=\"" + CTX_ROOT + "/images/frontimg/" + nodeImg + "\" name=\"" + nodeImg + "\" border=\"0\" onClick=\"getNode('" + fl_id + "',"+type+")\" style=\"cursor:pointer;\"> "
				          + "<img id=\"img_" + fl_id + "\" src=\"" + CTX_ROOT + "/images/frontimg/folder_open.png\" border=\"0\"> "
				          + "<span id=\"folder_" + fl_id + "\" onClick=\"getUserView("+type+",'" +fl_id + "')\" style=\"cursor:pointer;\">&nbsp;<a class=\"tree\">" + "<span id=\"color_"+fl_id+"\">" + fl_name + " " + lts_limit_str + "(" + file_cnt + ")</span></a>&nbsp;</span>"
				          + "<span id=\"nm_" + fl_id + "\" style=\"display:none\">" + fl_name + "</span>"
				          + "<span id=\"lf_" + fl_id + "\" style=\"display:none\">N</span>"
				          + "<span id=\"depth_" + fl_id + "\" style=\"display:none\">" + depth + "</span>"
				          + "<span id=\"lts_yn_" + fl_id + "\" style=\"display:none\">" + null2str(subVO.lts_yn, "N") + "</span>"
				          + "</td></tr></table>"
				          + "<span id=\"sub_" + fl_id + "\" style=\"display:none\"></span>"
				          + "</div>";
			}
			$("#color_"+p_fl_id).html(folderName);
			$("#sub_"+p_fl_id).html(subFolder);
		},
		fail:function(e) {
			alert(e);
		},
		error:function(a,b,c){
			if(a.status == 999){
				goUrl('/');
			}
//			goUrl('/','로그인이 필요합니다. subList');
//			alert(a.status);
//			alert(b);
//			alert(c);
		}
		
	});
}

var SEARCH_FL_ID = "";
function getUserFile(fl_id){
	SEARCH_FL_ID = fl_id;
	$.ajax({
		type: "POST",
		url: "/file/userFile",
		// data:  "fl_id=" + fl_id+"&curPage=1"+SEARCH_CURPAGE+"&searchText="+SEARCH_TEXT,
		data:  "fl_id=" + fl_id+"&curPage="+SEARCH_CURPAGE,
		dataType: "json",
		async: false,
		success:function(data) {
			var list = data.list;
			var nowDate = new Date();
			var curDate = nowDate.getTime();

			var retStr = "";
			var selectedId = "";
			var selectedName = "";
			var totalRow = 0;
			if (list != null && list.length > 0) {
				for (var i = 0; i < list.length; i++) {
					var fileVO = list[i];
					var fl_size = fileVO.FL_SIZE == null && fileVO.FL_SIZE=="" ? 0 : fileVO.FL_SIZE;
			//		var byteSize = StringUtil.getByteSize(CTX_ROOT, fl_size);	// java -> script
					var byteSize = fl_size;
					totalRow = fileVO.TOTCNT;
					if(fileVO.FL_TYPE == "D") {
			//			String fl_name = StringUtil.getAbbrString( (String)fileVO.get("FL_NAME") , 50);	// java -> script
						var fl_name = fileVO.FL_NAME; 	// java -> script
						retStr	+=		"	<tr ondblClick=\"javascript:selectFolder('"+fileVO.FL_ID+"')\">";
						retStr	+=		"		<td>&nbsp;</td>";
						retStr	+=		"		<td class=\"left\"><img class=\"btn\" src=\"/images/frontimg/iconFolder.png\" width=\"13\" height=\"16\" alt=\"\" >"+fl_name+"</td>";
			//			retStr	+=		"		<td>"+fileVO.get("CREATER_NAME")+"("+StringUtil.null2space(fileVO.get("CREATER_LOGIN_ID"))+")</td>";  // java -> script
						retStr	+=		"		<td>"+fileVO.CREATER_NAME+"("+fileVO.CREATER_LOGIN_ID+")</td>"; 
						retStr	+=		"		<td>&nbsp;</td>";
//				        retStr	+=		"		<td>"+DateUtil.toDateFormat(fileVO.get("DATE_CREATE"),"yy.MM.dd HH:mm:ss")+"</td>";
//				        retStr	+=		"		<td>"+fileVO.get("DATE_CREATE"),"yy.MM.dd")+"</td>";
				        retStr	+=		"		<td>"+toDateFormat(fileVO.DATE_CREATE)+"</td>";
				        retStr	+=		"		<td>-</td>";
				        retStr	+=		"	</tr>";
					} else {
						selectedId += ":" + fileVO.FL_ID;
						selectedName += ":" + fileVO.FL_NAME;
						
						var newFileImg = "";
						if ( fileVO.DATE_CREATE_END !=null && fileVO.DATE_CREATE_END != "" && curDate == fileVO.DATE_CREATE_END.substring(0, 8) )
							newFileImg = "<img src='/img/ioc_07.gif' width='14' height='8' border='0'>";
						
							var period_default = fileVO.PERIOD_DEFAULT == null || fileVO.PERIOD_DEFAULT =="" ? "":  // DateUtil.toDateShortForamat(fileVO.get("PERIOD_DEFAULT").substring(0, 8));
																																				toDateFormat( fileVO.PERIOD_DEFAULT);
							var fl_name = fileVO.PARENT_ID == null && fileVO.PARENT_ID == "" ? "" : //StringUtil.getAbbrString(fileVO.get("FL_NAME"), 50);
																													fileVO.FL_NAME;
							var creater_login_id = fileVO.CREATER_LOGIN_ID == null || fileVO.CREATER_LOGIN_ID == "" ? "" : //	StringUtil.null2space(fileVO.get("CREATER_LOGIN_ID"));
																																						fileVO.CREATER_LOGIN_ID;
//							String date_create_end = fileVO.get("DATE_CREATE_END")==null || fileVO.get("DATE_CREATE_END").equals("")?"":DateUtil.toDateFormat(fileVO.get("DATE_CREATE_END"),"yy.MM.dd HH:mm:ss");
							var date_create_end = fileVO.DATE_CREATE_END == null || fileVO.DATE_CREATE_END == "" ? "" : //	DateUtil.toDateFormat(fileVO.get("DATE_CREATE_END"),"yy.MM.dd");
																																						toDateFormat(fileVO.DATE_CREATE_END);
							var downYN = true;
							if( fileVO.DL_CNT >= data.downCount && folderType =="2" ){
								downYN = false;
							}
							
							var downStatus = downYN ? "" : "disabled" ;
							var chk_fl_id = downYN?"chk_fl_id":"";
							retStr	+=	"<tr id=\"_"+fileVO.FL_ID+"\" >";
							retStr	+= "	<td><input name='"+chk_fl_id+"' id='"+chk_fl_id+"' type='checkbox' value='"+fileVO.FL_ID+"' "+downStatus+" ></td>	";
							retStr	+= "	<td class=\"left\" style=\"cursor:pointer;\" onClick=\"goView('"+folderType+"','"+curId+"','"+fileVO.FL_ID+"');\"><img class=\"btn\" src=\""+getFileExtIcon(fileVO.FL_NAME)+"\" width=\"13\" height=\"16\" alt=\"\" >"+fl_name + newFileImg +"</td>";
							retStr	+=	"	<td>"+fileVO.CREATER_NAME+"("+creater_login_id+")</td>";
							retStr	+="	<td>"+toDateFormat( fileVO.PERIOD_DEFAULT )+"</td>";
							retStr	+="	<td>"+toDateFormat( fileVO.DATE_CREATE )+"</td>";
							retStr	+="	<td width=\"50\" align=\"right\" style=\"padding:0 2 0 0;text-align:right;\">"+number_format(byteSize)+"</td>";
							retStr	+="</tr>";
						}
					}
			} else {
				retStr	+=	"<tr>";
				retStr	+=	"<td colspan=\"6\">데이터가 없습니다!</td>";
				retStr	+="</tr>";
			}
			$("#userFileView").html(retStr);
			setPaginate( totalRow , data.curPage );
		},
		fail:function(e) {
			alert(e);
		},
		error:function(a,b,c){
			if(a.status == 999){
				goUrl('/');
			}
//			alert(a.status);
//			alert(b);
//			alert(c);
		}
	});
}

function getUserSearchFile(fl_id){
	SEARCH_FL_ID = fl_id;
	$.ajax({
		type: "POST",
		url: "/file/userFile",
		data:  "fl_id=" + fl_id+"&curPage="+SEARCH_CURPAGE+"&searchText="+SEARCH_TEXT,
		dataType: "json",
		async: false,
		success:function(data) {
			var list = data.list;
			var nowDate = new Date();
			var curDate = nowDate.getTime();

			var retStr = "";
			var selectedId = "";
			var selectedName = "";
			var totalRow = 0;
			if (list != null && list.length > 0) {
				for (var i = 0; i < list.length; i++) {
					var fileVO = list[i];
					var fl_size = fileVO.FL_SIZE == null && fileVO.FL_SIZE=="" ? 0 : fileVO.FL_SIZE;
			//		var byteSize = StringUtil.getByteSize(CTX_ROOT, fl_size);	// java -> script
					var byteSize = fl_size;
					totalRow = fileVO.TOTCNT;
					if(fileVO.FL_TYPE == "D") {
			//			String fl_name = StringUtil.getAbbrString( (String)fileVO.get("FL_NAME") , 50);	// java -> script
						var fl_name = fileVO.FL_NAME; 	// java -> script
						retStr	+=		"	<tr ondblClick=\"javascript:selectFolder('"+fileVO.FL_ID+"')\">";
						retStr	+=		"		<td>&nbsp;</td>";
						retStr	+=		"		<td class=\"left\"><img class=\"btn\" src=\"/images/frontimg/iconFolder.png\" width=\"13\" height=\"16\" alt=\"\" >"+fl_name+"</td>";
			//			retStr	+=		"		<td>"+fileVO.get("CREATER_NAME")+"("+StringUtil.null2space(fileVO.get("CREATER_LOGIN_ID"))+")</td>";  // java -> script
						retStr	+=		"		<td>"+fileVO.CREATER_NAME+"("+fileVO.CREATER_LOGIN_ID+")</td>"; 
						retStr	+=		"		<td>&nbsp;</td>";
//				        retStr	+=		"		<td>"+DateUtil.toDateFormat(fileVO.get("DATE_CREATE"),"yy.MM.dd HH:mm:ss")+"</td>";
//				        retStr	+=		"		<td>"+fileVO.get("DATE_CREATE"),"yy.MM.dd")+"</td>";
				        retStr	+=		"		<td>"+toDateFormat(fileVO.DATE_CREATE)+"</td>";
				        retStr	+=		"		<td>-</td>";
				        retStr	+=		"	</tr>";
					} else {
						selectedId += ":" + fileVO.FL_ID;
						selectedName += ":" + fileVO.FL_NAME;
						
						var newFileImg = "";
						if ( fileVO.DATE_CREATE_END !=null && fileVO.DATE_CREATE_END != "" && curDate == fileVO.DATE_CREATE_END.substring(0, 8) )
							newFileImg = "<img src='/img/ioc_07.gif' width='14' height='8' border='0'>";
						
							var period_default = fileVO.PERIOD_DEFAULT == null || fileVO.PERIOD_DEFAULT =="" ? "":  // DateUtil.toDateShortForamat(fileVO.get("PERIOD_DEFAULT").substring(0, 8));
																																				toDateFormat( fileVO.PERIOD_DEFAULT);
							var fl_name = fileVO.PARENT_ID == null && fileVO.PARENT_ID == "" ? "" : //StringUtil.getAbbrString(fileVO.get("FL_NAME"), 50);
																													fileVO.FL_NAME;
							var creater_login_id = fileVO.CREATER_LOGIN_ID == null || fileVO.CREATER_LOGIN_ID == "" ? "" : //	StringUtil.null2space(fileVO.get("CREATER_LOGIN_ID"));
																																						fileVO.CREATER_LOGIN_ID;
//							String date_create_end = fileVO.get("DATE_CREATE_END")==null || fileVO.get("DATE_CREATE_END").equals("")?"":DateUtil.toDateFormat(fileVO.get("DATE_CREATE_END"),"yy.MM.dd HH:mm:ss");
							var date_create_end = fileVO.DATE_CREATE_END == null || fileVO.DATE_CREATE_END == "" ? "" : //	DateUtil.toDateFormat(fileVO.get("DATE_CREATE_END"),"yy.MM.dd");
																																						toDateFormat(fileVO.DATE_CREATE_END);
							var downYN = true;
							if( fileVO.DL_CNT >= data.downCount && folderType =="2" ){
								downYN = false;
							}
							
							var downStatus = downYN ? "" : "disabled" ;
							var chk_fl_id = downYN?"chk_fl_id":"";
							retStr	+=	"<tr id=\"_"+fileVO.FL_ID+"\" >";
							retStr	+= "	<td><input name='"+chk_fl_id+"' id='"+chk_fl_id+"' type='checkbox' value='"+fileVO.FL_ID+"' "+downStatus+" ></td>	";
							retStr	+= "	<td class=\"left\" style=\"cursor:pointer;\" onClick=\"goView('"+folderType+"','"+curId+"','"+fileVO.FL_ID+"');\"><img class=\"btn\" src=\""+getFileExtIcon(fileVO.FL_NAME)+"\" width=\"13\" height=\"16\" alt=\"\" >"+fl_name + newFileImg +"</td>";
							retStr	+=	"	<td>"+fileVO.CREATER_NAME+"("+creater_login_id+")</td>";
							retStr	+="	<td>"+toDateFormat( fileVO.PERIOD_DEFAULT )+"</td>";
							retStr	+="	<td>"+toDateFormat( fileVO.DATE_CREATE )+"</td>";
							retStr	+="	<td width=\"50\" align=\"right\" style=\"padding:0 2 0 0;text-align:right;\">"+number_format(byteSize)+"</td>";
							retStr	+="</tr>";
						}
					}
			} else {
				retStr	+=	"<tr>";
				retStr	+=	"<td colspan=\"6\">데이터가 없습니다!</td>";
				retStr	+="</tr>";
			}
			$("#userFileView").html(retStr);
			setPaginate( totalRow , data.curPage );
		},
		fail:function(e) {
			alert(e);
		},
		error:function(a,b,c){
			if(a.status == 999){
				goUrl('/');
			}
//			alert(a.status);
//			alert(b);
//			alert(c);
		}
	});
}

function toDateFormat(arg1){
	var yyyy = arg1.substring(0,4);
	var mm = arg1.substring(4,6);
	var dd = arg1.substring(6,8);
	
	return yyyy+"/"+mm+"/"+dd;
}
function number_format(num){
 //   var num_str = num.toString();
    var num_str = Math.ceil(Number(num)/1000);
    num_str = num_str.toString();
    var result = "";
    for(var i=0; i<num_str.length; i++){
        var tmp = num_str.length - (i+1);
 
        if(((i%3)==0) && (i!=0))    result = ',' + result;
        result = num_str.charAt(tmp) + result;
    }
   return result+" KB"; 
}

//발신함
function getSendBox(){
	PAGE_URL = "sendBox";
	selectFolder("sendBox",false,3);
	$.ajax({
		type: "POST",
		url: "/file/sendBox",
		data:  "fl_id=",
		dataType: "html",
		async: false,
		success:function(data) {
			$("#containerBside").html(data);
		//	PAGE_URL = url;
			searchSendBox();
		},
		fail:function(e) {
			alert(e);
		},
		error:function(a,b,c){
			if(a.status == 999){
				goUrl('/');
			}
		}
	});
}

//로컬다운로드
function getLocalFile(){

	PAGE_URL = "localFile";
	selectFolder("localFile",false,4);
	$.ajax({
		type: "POST",
		url: "/file/localFile",
		data:  "fl_id=",
		dataType: "html",
		async: false,
		success:function(data) {
			$("#containerBside").html(data);
		//	PAGE_URL = url;
			searchSendBox();
		},
		fail:function(e) {
			alert(e);
		},
		error:function(a,b,c){

			if(a.status == 999){
				goUrl('/');
			}
		}
	});
}

function setMainCount(){
	$.ajax({
		type: "POST",
		url: "/file/mainCount",
		data:  "fl_id=" ,
		dataType: "json",
		async: false,
		success:function(data) {
			var myAcceptance = data.myAcceptance;
			var myFolder = data.myFolder;
			var receiverFolder = data.receiverFolder;
			var noBreakFolder = data.noBreakFolder;
			$("#myAcceptanceCntLayer").html( myAcceptance+" 건" );
			$("#myFolderCntLayer").html( myFolder+" 건" );
			$("#receiverFolderCntLayer").html( receiverFolder+" 건" );
			$("#noBreakFolderCntLayer").html( noBreakFolder+" 건" );

		},
		fail:function(e) {
			alert(e);
		},
		error:function(a,b,c){

			if(a.status == 999){
				goUrl('/');
			}
		}
	});
}