﻿$(function () {
    //검은 막 띄우기 
    $('.openMask').click(function (e) {
        e.preventDefault();
        wrapWindowByMask();
    });

    //닫기 버튼을 눌렀을 때 
    $('#fullmenu-wrap .fmenu-close').click(function (e) {
        //링크 기본동작은 작동하지 않도록 한다. 
        e.preventDefault();
        $('#mask').hide();
    });
    
    $('.guide_info').click(function (e) {
        e.preventDefault();
        var maskHeight = $(document).height();
        var maskWidth = $(window).width();

        //마스크의 높이와 너비를 화면 것으로 만들어 전체 화면을 채운다. 
        $('#popGuide').css({ 'width': '100%', 'height': maskHeight });
        $('#popGuide').fadeIn(0);
        $('#popGuide-warp').show();
    });

    $('#popGuide-warp .popGuide-close').click(function (e) {
        e.preventDefault();
        $('#popGuide').hide();
    
    });
    
    

    $('.person_info').click(function (e) {
            e.preventDefault();
            var maskHeight = $(document).height();
            var maskWidth = $(window).width();

            //마스크의 높이와 너비를 화면 것으로 만들어 전체 화면을 채운다. 
            $('#popPerson').css({ 'width': '100%', 'height': maskHeight });
            $('#popPerson').fadeIn(0);
            $('#popPerson-warp').show();
        });

        $('#popPerson-warp .popPerson-close').click(function (e) {
            e.preventDefault();
            $('#popPerson').hide();

        });

    // 탭메뉴
    $(".popGuide_tab li").each(function () {

        $(this).bind("click", function () {
            $(this).parent().find('li').removeClass("on").addClass("off");
            $(this).addClass("on");

            $(".popGuide_tab li a").each(function () {
                if ($(this).attr("class") != "") {
                    $("#" + $(this).attr("class")).hide();
                }
            });

            if ($(this).find("a").attr("class") != "") {
                $("#" + $(this).find("a").attr("class")).show();
            }

        });
    });
    

});

function wrapWindowByMask() {
    //화면의 높이와 너비를 구한다. 
    var maskHeight = $(document).height();
    var maskWidth = $(window).width();

    //마스크의 높이와 너비를 화면 것으로 만들어 전체 화면을 채운다. 
    $('#mask').css({ 'width': '100%', 'height': maskHeight });
    $('#mask').fadeIn(0);
    $('#fullmenu-wrap').show();
}

