//퓨전차트용Color
var palettecolors = "#f8bd19,#008ee4,#33bdda,#e44a00,#6baa01,#583e78";

func_initSetting = function(type, autoFlag) {
	$("th").attr("nowrap","nowrap");

	$("#btnSearch").click(function() {
		if(func_dataChk(type)) {
			func_action(type, "search");
		}else {
			func_action("search");
		}
	});
	
	if(func_dataChk(type)) {
		func_action(type);
	}
};

func_defaultSumType = function(classNmArr) {
	if(!func_dataChk(classNmArr)) return;
	$.each(classNmArr, function(i,v){
		$("#"+v).attr("readonly","readonly");
		$("#"+v).attr("disabled","disabled");
		$("#"+v).inputmask({
			alias: "numeric",
	        groupSeparator: ",",
	        autoGroup: true
		});			
	});
};

func_maxLength = function(maxLength, sosu) {
	maxLength = parseInt(maxLength);
	sosu = parseInt(func_dataChkVal(sosu)?sosu:"0");
	if(maxLength > 3) {
		var gap = maxLength + parseInt(maxLength/3); 
		if(maxLength%3==0) gap -= 1;
		maxLength = gap; 
	}
	if(sosu > 0) {
		maxLength += (sosu + 1);
	}
	return maxLength;
};

func_sum = function(id, digit, targetType, resultType) {
	var totalSum = 0;
	targetType = func_dataChkVal(targetType, "VAL");
	if("VAL"==targetType) {
		$.each($("input:text"), function() {
			if(!$(this).hasClass(id)) return true;
			totalSum += parseFloat(func_dataChkVal($(this).val().replace(/\,/g, ""),"0"));
		});
	}else {
		$.each($("."+id), function() {
			if(!$(this).hasClass(id)) return true;
			totalSum += parseFloat(func_dataChkVal($(this).text().replace(/\,/g, ""),"0"));
		});
	}
	if(digit>0) totalSum = parseFloat(totalSum).toFixed(digit);
	else 		totalSum = Math.round(totalSum);
	totalSum += "";
	if(isNaN(totalSum)) totalSum = "";
	if("TEXT" == resultType) {
		$("#"+id).text(totalSum);
	}else {
		$("#"+id).val(totalSum);
	}
};

func_numberTran = function(val, cond) {
	if(null==val||""==val||typeof(val)=='undefined') return 0;
	if(cond == 'PERCENT') return parseInt(val) / 100;
	if(cond == 'FLOAT') return parseFloat(val);
	return parseInt(val);
};

func_dataExistChk = function(flagStr, alertStopFlag) {
	var flag = ("true"==flagStr.toLowerCase())?true:false;
	var txt = "년도";
	if(!flag && !func_dataChk(alertStopFlag)) {
		if($("#month").length > 0) txt = "월";
		alert("해당 " + txt + "의 데이터가 존재하지 않습니다.");
	}
	return flag;
};

func_dataChk = function(obj) {
	if(null!=obj&&""!=obj&&typeof(obj)!='undefined') return true;
	else return false;
};

func_dataChkVal = function(obj, str) {
	var result = "";
	if(func_dataChk(obj)) {
		return obj;
	}else {
		if(func_dataChk(str)) {
			result = str;
		}
	}
	return result;
};

func_graphOptChk = function(option, optionVal, isNumber) {
	if(func_dataChk(option) && func_dataChk(option[optionVal])) {
		if(func_dataChk(isNumber) || isNumber) {
			if(!isNaN(option[optionVal])) return true;
		}else {
			return true;
		}
	}
	return false;
};

func_encode = function(strArr) {
	var resultArr = [];
	$.each(strArr, function(i, v) {
		resultArr.push(encodeURIComponent(v));
	});
	return resultArr;
};

//inputmask 옵션설정
func_inputMaskOpt = function(pointUpDigit, pointDownDigit) {
	pointUpDigit = func_numberTran(pointUpDigit);
	pointDownDigit = func_numberTran(pointDownDigit);
	var opt = new Array();
	if(pointUpDigit > 0 && pointDownDigit < 1) {
		opt = {
			alias: "numeric",
			radixPoint: "",
			integerDigits: pointUpDigit,
	        groupSeparator: ",",
	        autoGroup: true
		};
	}else if(pointUpDigit > 0 && pointDownDigit > 0){
		opt = {
			alias: "decimal",
			radixPoint: ".",
			integerDigits: pointUpDigit,
			digits: pointDownDigit,
		    groupSeparator: ",",
		    autoGroup: true,
		    allowMinus: false,
		    allowPlus: false
		};
	}else {
		opt = {
			alias: "numeric",
	        groupSeparator: ",",
	        autoGroup: true
	    };
	}
	return opt;
};

//단위설정
func_unitText = function(val, preStr, subStr, forceUnit) {
	var preTxt = (func_dataChk(preStr)?preStr:"")+"(단위:";
	var subTxt = (func_dataChk(subStr)?subStr:"")+")";
	var txt = "";
	var unitTxtArr = ["천","만","십만","백만","천만","억","십억","백억","천억","조","십조","백조"];
	if(func_dataChk(forceUnit)) return forceUnit;
	if(func_dataChk(val) && !isNaN(val)) {
		var flag = false;
		for(var i=0; i<unitTxtArr.length; i++) {
			if(parseInt(val) / (1000 * (Math.pow(10,i))) == 1) flag = true;
			if(flag) { txt = unitTxtArr[i];	break; }
		}
		if("" != txt) return preTxt + txt + subTxt;  
	}
	return "";
};

//증감값 구하기
func_plusVal = function(minVal, maxVal) {
	minVal = (""+minVal).replace(/-/g,"");
	maxVal = (""+maxVal).replace(/-/g,"");
	maxVal = maxVal.substring(maxVal.length - minVal.length);
	var charat = -1;
	var minimum = 0;
	if(minVal.length > maxVal.length) minimum = maxVal.length;
	else minimum = minVal.length;
	for(var i=0; i<minimum; i++) {
		if(minVal.charAt(i) != maxVal.charAt(i)) {
			charat = i+1;
			break;
		}
	}
	if(charat == -1) {
		return 10;
	}else {
		var cha = minimum - charat;
		//if(cha > 1) cha =- 1;
		return Math.pow(10, Math.abs(cha));
	}
};

//데이터 가공
func_dataProcess = function(keyArr, unitArr) {
	var data = new Object();
	data.menuId = $("#menuId").val();
	data.year = $("#year").val();
	data.type = $("#type").val();
	data.keyArr = func_encode(keyArr);
	if(func_dataChk(unitArr)) data.unitArr = unitArr;
	return data;
};

//데이터셋 Get
func_getDataSet = function(data, url) {
	var result = null;
	$.ajax({
		type: "GET",
		url: url,
		data: data,
	 	dataType: "json",
		async: false,
		success:function(data) {
			result = data.dataList;
		},
		fail:function() {
			alert("데이터 통신중 오류가 발생했습니다.");
		}
	});
	return result;
};

//D3그래프설정
func_d3_graph = function(targetObj, dataSet, option) {
	if(!func_dataChk(targetObj) || !func_dataChk(dataSet)) return;
	
	var gOpt = {
		 width    : func_graphOptChk(option,'width')    ? option.width    : 1100
		,height   : func_graphOptChk(option,'height')   ? option.height   : 410
		,x_move   : func_graphOptChk(option,'x_move')   ? option.x_move   : 0
		,y_move   : func_graphOptChk(option,'y_move')   ? option.y_move   : 0
		,y_minVal : func_graphOptChk(option,'y_minVal') ? option.y_minVal : d3.min(dataSet, function(d) { return d.val; })
		,y_maxVal : func_graphOptChk(option,'y_maxVal') ? option.y_maxVal : d3.max(dataSet, function(d) { return d.val; })
		,x_ticCnt : func_graphOptChk(option,'x_ticCnt') ? option.x_ticCnt : 12
		,y_ticCnt : func_graphOptChk(option,'y_ticCnt') ? option.y_ticCnt : 8
		,x_unit   : func_graphOptChk(option,'x_unit', false) ? option.x_unit : '' 
		,y_unit   : func_graphOptChk(option,'y_unit', false) ? option.y_unit : ''
		,stColor  : func_graphOptChk(option,'stColor', false)? d3.scale.ordinal().range(option.stColor) : d3.scale.category10()
	};
	
	var plus = func_plusVal(gOpt.y_minVal, gOpt.y_maxVal);
	var margin = {top: 40, right: 20, bottom: 40, left: 50},
    		width = 960 - margin.left - margin.right,
    		height = 400 - margin.top - margin.bottom;
	var dateFormat = d3.time.format("%m월"); 
	var parseDate = d3.time.format("%Y %m").parse;
	var bisectDate = d3.bisector(function(d) { return d.date; }).left;
	var color = gOpt.stColor;
	var x = d3.time.scale().range([gOpt.x_move, width+gOpt.x_move]);
	var y = d3.scale.linear().range([height+gOpt.y_move, gOpt.y_move]);

	var xAxis = d3.svg.axis().scale(x)
	    		  .orient("bottom").ticks(gOpt.x_ticCnt).tickFormat(dateFormat);
	var yAxis = d3.svg.axis().scale(y)
	    		  .orient("left").ticks(gOpt.y_ticCnt);

	var valueLine = d3.svg.line()
	    			  .x(function(d) { return x(d.date); })
	    			  .y(function(d) { return y(d.val); });
	    
	var svg = d3.select(targetObj)
			    .append("svg")
			    .attr("width", gOpt.width)
			    .attr("height", gOpt.height)
			    .append("g")
			    .attr("transform", "translate(" + margin.left + "," + margin.top + ")"); 
	
    dataSet.forEach(function(d) {
    	d.date = parseDate(d.date);
	  	d.val = +d.val;
    });

    x.domain(d3.extent(dataSet, function(d) { return d.date; }));
    y.domain([gOpt.y_minVal-plus, gOpt.y_maxVal+plus]);

    var dataNest = d3.nest()
        .key(function(d) {return d.symbol;})
        .entries(dataSet);

    dataNest.forEach(function(d,i) {
    	var focus = svg.append("g").style("display", "none");
    	var maxlength = d.values.length-1;
    	
    	function mousemove() {
            var x0 = x.invert(d3.mouse(this)[0]);
            var y0 = y.invert(d3.mouse(this)[0]);
            var i = bisectDate(dataSet, x0, 0);
            
            var d0 = dataSet[i-1];
            var d1 = dataSet[i];
            var dx = (func_dataChk(d0)&&func_dataChk(d1)) ? (x0 - d0.date > d1.date - x0 ? d1 : d0) : d0;
            dataSet.forEach(function(d) {
            	if(d.date == dx.date) {
            		var dxMinus = Math.abs(y0 - dx.val); 
            		var dMinus = Math.abs(y0 - d.val);
            		if(dMinus > dxMinus) {
            			dx = d;
            			return false;
            		}
            	}
            });
            
            focus.select("circle.y")
                 .attr("transform", "translate(" + x(dx.date) + "," + y(dx.val) + ")");
            focus.select("text.y1")
	        	 .attr("transform", "translate(" + x(dx.date) + "," + y(dx.val) + ")")
	        	 .text(commify(d.realval));
            focus.select("text.y2")
            	 .attr("transform", "translate(" + x(dx.date) + "," + y(dx.val) + ")")
            	 .text(commify(dx.realval));
        };
    	
        svg.append("path")
            .attr("class", "line")
            .style("stroke", function() { return d.color = color(d.key); })
            .attr("id", 'tag'+targetObj.replace(/[^a-zA-Z0-9]/g,"")+"Id"+i)
            .attr("d", valueLine(d.values))
	        .style("pointer-events", "all")
	        .on("mouseover", function() { focus.style("display", null); })
	        .on("mouseout", function() { focus.style("display", "none"); })
	        .on("mousemove", mousemove);
        
        svg.append("text")
	       .attr("transform", "translate(" + x(d.values[maxlength].date) + "," + y(d.values[maxlength].val) + ")")
	       .attr("x", 3)
	       .attr("y", 3)
	       .attr("class", "legend")
	       .style("fill", function() { return d.color = color(d.key); })
	       .on("click", function() {
	    	   var active   = d.active ? false : true, 
	           newOpacity = active ? 0 : 1;
	           d3.select("#tag"+targetObj.replace(/[^a-zA-Z0-9]/g,"")+"Id"+i)
	             .transition().duration(100)
	             .style("opacity", newOpacity);
	           d.active = active;
	          })
	       .text(d.key);
        
       focus.append("circle")
	   	    .attr("class", "y")
	   	    .style("fill", "none")
	   	    .style("stroke", function() { return d.color = color(d.key); })
	   	    .attr("r", 4);
   
	   focus.append("text")
	        .attr("class", "y1")
	        .style("stroke", "white")
	        .style("stroke-width", "3.5px")
	        .style("opacity", 1)
	        .attr("dx", 8)
	        .attr("dy", "-.3em");
	   
	   focus.append("text")
	     	.attr("class", "y2")
	   	    .attr("dx", 8)
	   	    .attr("dy", "-.3em");
    });
    
    svg.append("g")
       .attr("class", "x axis")
       .attr("transform", "translate(0, " + (height+gOpt.y_move) + ")")
       .call(xAxis)
	   .append("text")
	   .attr("transform", "translate(" + gOpt.x_move + ", 0)")
       .attr("x", 980)
       .attr("y", 5)
       .attr("dy", ".100em")
       .style("text-anchor", "end")
       .text(gOpt.x_unit);

    svg.append("g")
       .attr("class", "y axis")
       .attr("transform", "translate(" + gOpt.x_move + ", 0)")
       .call(yAxis)
       .append("text")
       .attr("transform", "translate(0, " + gOpt.y_move + ")")
       .attr("x", 10 + (gOpt.y_unit.length*2))
       .attr("y", -15)
       .attr("dy", ".100em")
       .style("text-anchor", "end")
       .text(gOpt.y_unit);
};

//FusionChart 옵션설정
func_fusionChartOption = function(chartId, option) {
	var $chart = $("#"+chartId).find("chart");
	$chart.attr("palettecolors"			, func_graphOptChk(option,'palettecolors',false)? option.palettecolors 			: palettecolors);
	$chart.attr("bgcolor"				, func_graphOptChk(option,'bgcolor',false) 		? option.bgcolor 				: "#ffffff");
	$chart.attr("divlinecolor"			, func_graphOptChk(option,'divlinecolor',false)	? option.divlinecolor 			: "#cccccc");
	$chart.attr("plotgradientcolor"		, func_graphOptChk(option,'plotgradientcolor',false)? option.plotgradientcolor				: "");
	$chart.attr("canvasbordercolor"		, func_graphOptChk(option,'canvasbordercolor', false)  ? ""+option.canvasbordercolor 		: "#cccccc");
	$chart.attr("showalternatehgridcolor",func_graphOptChk(option,'showalternatehgridcolor',false)? option.showalternatehgridcolor	: "1");
	$chart.attr("baseFontSize"			, func_graphOptChk(option,'baseFontSize') 		? ""+option.baseFontSize		: "12");
	$chart.attr("formatNumberScale"		, func_graphOptChk(option,'formatNumberScale')	? ""+option.formatNumberScale	: "0");
	$chart.attr("sFormatNumberScale"	, func_graphOptChk(option,'sFormatNumberScale')	? ""+option.sFormatNumberScale	: "0");
	$chart.attr("decimalSeparator"		, func_graphOptChk(option,'decimalSeparator')	? ""+option.decimalSeparator	: "");
	$chart.attr("showValues"			, func_graphOptChk(option,'showValues') 		? ""+option.showValues 			: "0");
	$chart.attr("showborder"			, func_graphOptChk(option,'showborder') 		? ""+option.showborder 			: "0");
	$chart.attr("showplotborder"		, func_graphOptChk(option,'showplotborder') 	? ""+option.showplotborder 		: "0");
	$chart.attr("showcanvasborder"		, func_graphOptChk(option,'showcanvasborder') 	? ""+option.showcanvasborder 	: "0");
	$chart.attr("canvasborderalpha"		, func_graphOptChk(option,'canvasborderalpha')  ? ""+option.canvasborderalpha 	: "100");
	$chart.attr("canvasborderthickness"	, func_graphOptChk(option,'canvasborderthickness') ? ""+option.canvasborderthickness	: "1");
	$chart.attr("captionpadding"		, func_graphOptChk(option,'captionpadding')  	? ""+option.captionpadding 		: "30");
	$chart.attr("labelpadding"			, func_graphOptChk(option,'labelpadding')  		? ""+option.labelpadding 		: "5");
	$chart.attr("canvaspadding"			, func_graphOptChk(option,'canvaspadding')  	? ""+option.canvaspadding 		: "25");
	$chart.attr("yaxisvaluespadding"	, func_graphOptChk(option,'yaxisvaluespadding') ? ""+option.yaxisvaluespadding 	: "5");
	$chart.attr("yaxisnamepadding"		, func_graphOptChk(option,'yaxisnamepadding') 	? ""+option.yaxisnamepadding 	: "15");
	$chart.attr("setadaptiveymin"		, func_graphOptChk(option,'setadaptiveymin')  	? ""+option.setadaptiveymin 	: "1");
	$chart.attr("setadaptivesymin"		, func_graphOptChk(option,'setadaptivesymin') 	? ""+option.setadaptivesymin 	: "1");
	$chart.attr("linethickness"			, func_graphOptChk(option,'linethickness')    	? ""+option.linethickness 		: "2");
	$chart.attr("legendshadow"			, func_graphOptChk(option,'legendshadow')    	? ""+option.legendshadow 		: "0");
	$chart.attr("legendborderalpha"		, func_graphOptChk(option,'legendborderalpha')  ? ""+option.legendborderalpha 	: "0");
	$chart.attr("centeryaxisname"		, func_graphOptChk(option,'centeryaxisname')  	? ""+option.centeryaxisname 	: "0");
	$chart.attr("xaxisname"				, func_graphOptChk(option,'xaxisname',false)  	? ""+option.xaxisname 			: "기준년월");
	$chart.attr("yaxisname"				, func_graphOptChk(option,'yaxisname',false)  	? ""+option.yaxisname 			: "");
	$chart.attr("pyaxisname"			, func_graphOptChk(option,'pyaxisname',false)  	? ""+option.pyaxisname 			: "");
	$chart.attr("syaxisname"			, func_graphOptChk(option,'syaxisname',false)  	? ""+option.syaxisname 			: "");
	$chart.attr("snumbersuffix"			, func_graphOptChk(option,'snumbersuffix',false)? ""+option.snumbersuffix 		: "");
};

//FusionChart 그리기(※FusionCharts.js가 include 되어있어야 함)
func_fusionChart = function(swfName, graphId, graphXml, gWidth, gHeight) {
	var swfUrl = "/flash/";
	var subfix = ".swf";
	var fullUrl = swfUrl+swfName+subfix;
	var width = (func_dataChk(gWidth)?gWidth:GRAPH_WIDTH);
	var height = (func_dataChk(gHeight)?gHeight:GRAPH_HEIGHT);
	var	fChart = new FusionCharts(fullUrl, graphId, width, height);
	fChart.setDataXML($('#'+graphXml).val());
	fChart.setTransparent("transparent");
	fChart.render(graphId);
};
