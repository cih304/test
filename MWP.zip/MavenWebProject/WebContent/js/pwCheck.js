
/*
	비밀번호 제한조건 
	1. 영문소문자 및 영문대문자,숫자 및특수문자가 혼용되도록
	2. 입력하는 아이디,닉네임,이메일,휴대폰번호와 동일하거나 4자리 이상 같지 않도록 ( 기본은 주석처리 )
	3. 연속적인 숫자 4자리나 영문자4자리가 되지 않도록 
 */ 

var ERR_MSG;
function isValidPassword(pwd)
{
	
	//널인지?
    if(isEmpty(pwd))
    {
        return false;
    }
	
    if (pwd.indexOf(' ') > -1) {
        ERR_MSG = "공백은 입력할 수 없습니다.";
        return false;
    }

    // 8자 미만인지 확인
    // 1종인지 확인
    // 2종 이면서 10자 미만인지 확인
    // 3종이면서 8자 미만인지 확인
    
    
    // 비밀번호는 8자리이상 ..   
    if(pwd.length < 8 )
    {
    	ERR_MSG = "비밀번호는 영문 대/소, 숫자, 특수기호 중 \n 2종류 10자 이상, 또는 3종류 이상 8자 이상으로 입력해 주세요.";
        return false;
    }
    
	// 영문만 있는경우 false
	if ( engCheckPass(pwd) == false) {		
		ERR_MSG = "비밀번호는 영문 대/소, 숫자, 특수기호 중 \n 2종류 10자 이상, 또는 3종류 이상 8자 이상으로 입력해 주세요.";
		return false;
	}
	//숫자만 있는경우 false
	if ( numCheckPass(pwd) == false) {		
		ERR_MSG = "비밀번호는 영문 대/소, 숫자, 특수기호 중 \n 2종류 10자 이상, 또는 3종류 이상 8자 이상으로 입력해 주세요.";
		return false;
		
	}
	//특수기호만 있는경우 false
	if ( specialCheakPass(pwd) == false) {		
		ERR_MSG = "비밀번호는 영문 대/소, 숫자, 특수기호 중 \n 2종류 10자 이상, 또는 3종류 이상 8자 이상으로 입력해 주세요.";
		return false;
	}

	//숫자와 특수기호만 있고 10자리 미만인 경우 false
	if ( CheckNumSpecialPass(pwd) == false && pwd.length < 10) {		
		ERR_MSG = "비밀번호는 영문 대/소, 숫자, 특수기호 중 \n 2종류 10자 이상, 또는 3종류 이상 8자 이상으로 입력해 주세요.";
		return false;
	}

	//영문과 특수기호만 있고 10자리 미만인 경우 false
	if ( CheckEngSpecialPass(pwd) == false && pwd.length < 10) {		
		ERR_MSG = "비밀번호는 영문 대/소, 숫자, 특수기호 중 \n 2종류 10자 이상, 또는 3종류 이상 8자 이상으로 입력해 주세요.";
		return false;
	}

	//영문과 숫자만 있고 10자리 미만인 경우 false
	if ( CheckEngNumPass(pwd) == false && pwd.length < 10) {		
		ERR_MSG = "비밀번호는 영문 대/소, 숫자, 특수기호 중 \n 2종류 10자 이상, 또는 3종류 이상 8자 이상으로 입력해 주세요.";
		return false;
	}

	//3종 다 있으나 8자 미만인 경우 false
	if ( CheckAllPass(pwd) == false && pwd.length < 8) {		
		ERR_MSG = "비밀번호는 영문 대/소, 숫자, 특수기호 중 \n 2종류 10자 이상, 또는 3종류 이상 8자 이상으로 입력해 주세요.";
		return false;
	}
			
	//if (CheckEngSpecialPass(pwd) == false ) {
	//	ERR_MSG = "영문과 특수문자만으로 구성된 문자는 비밀번호로 사용할수 없습니다.!\n";
	//	return false;
	//}
	
    // var alpaBig= "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    // var alpaSmall= "abcdefghijklmnopqrstuvwxyz";   
        
    if(isNum(pwd)){
       ERR_MSG = "비밀번호는 숫자를 하나 이상 포함해야 합니다.";
        return false;
    }
    
    //for(var i=0;i < alpaBig.length - pwd.length+1;i++){
    //   if(alpaBig.substring(i,i+pwd.length) == pwd)
    //    {
    //        ERR_MSG = "ABCDEF처럼 연속된 문자는 사용할 수 가 없습니다.";
    //        return false;
    //    }
    // }
    /*       
   	var specalChar = '0123456789';
	for( var i=0; i<specalChar.length-3; i++ )	
	{
		if ( pwd.indexOf(specalChar.substring(i,i+4)) >=0 ) 
		{								
			ERR_MSG = "비밀번호는 연속으로 4글자의 숫자는 사용할 수 없습니다.!\n";
			return false;
		}	
	}
    */
   	var specalChar = new Array(				"0123456789"
   												, 	"qwertyuiop"
   												, 	"asdfghjkl"
   												, 	"zxcvbnm"
   												, 	"poiuytrewq"
   												, 	"lkjhgfdsa"
   												, 	"mnbvcxz"									
   										);									

	for( var z=0; z<specalChar.length; z++ ){
		var charArray = specalChar[z];
		for( var i=0; i<charArray.length-3; i++ ){
			if (( pwd.toLowerCase()).indexOf(charArray.substring(i,i+4)) >=0 ) 
			{
				if(z==0){
					ERR_MSG = "비밀번호는 연속으로 4글자의 숫자는 사용할 수 없습니다.!\n";
					return false;
				}else{
		//			ERR_MSG = "비밀번호는 키보드 배열금지에 위반되었습니다..!\n";
		//			return false;
					
				}
			}
		}
	}


	
	
	
	var specalChar2 = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz';
	for( var i=0; i<specalChar2.length-3; i++ )	
	{
		if ( pwd.indexOf(specalChar2.substring(i,i+4)) >=0 ) 
		{								
			ERR_MSG = "비밀번호는 연속으로 4글자의 영문은 사용할 수 없습니다.!\n";
			return false;
		}	
	}
	
    
    //for(i=0;i < alpaSmall.length - pwd.length+1;i++){
    //    if(alpaSmall.substring(i,i+pwd.length) == pwd)
    //    {
    //        ERR_MSG = "abcdef처럼 연속된 문자는 사용할 수 가 없습니다.";
    //        return false;
    //    }
   	// }
    
    for(i=1;i < pwd.length;i++){
        if(pwd.substring(0,1) != pwd.substring(i,i+1) )
            return true;
    }
    ERR_MSG = "비밀번호는 같은 문자만 연속해서 입력할 수 없습니다";
    return false;
}
// 영문만 있는경우 false
function engCheckPass(target)
{  var Digit = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz';
   for (i=0 ;i<=target.length ;i++)
   {  if(Digit.indexOf(target.substring(i,i+1)) < 0) 
	  {  
   return true;
	  }
   }
   return false;
}

//숫자만 있는경우 false
function numCheckPass(target)
{  
   var Digit = '1234567890';
   for (i=0 ;i<=target.length ;i++)
   {  if(Digit.indexOf(target.substring(i,i+1)) < 0) 
	  {  
		return true;
	  }
   }
   return false;
}

//특수기호만 있는경우 false
function specialCheakPass(target)
{
	var Digit = " `~!@#$%^&*()_-+=|\\[]{}:;,<.>/?'\"";
   for (i=0 ;i<=target.length ;i++)
   {  if(Digit.indexOf(target.substring(i,i+1)) < 0) 
	  {  
   return true;
	  }
   }
   return false;
}

//숫자와 특수기호만 있는경우 false
function CheckNumSpecialPass(Data) 
{
	var nochk="0123456789 `~!@#$%^&*()_-+=|\\[]{}:;,<.>/?'\"";
	for (i=0; i<Data.length; i++)
	{
		if(nochk.indexOf(Data.substring(i,i+1)) < 0) 
		{ 
			return true;
		}
	}
	return false ;
}

//영문과 특수기호만 있는경우 false
function CheckEngSpecialPass(Data) 
{
	var nochk="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz `~!@#$%^&*()_-+=|\\[]{}:;,<.>/?'\""
	for (i=0; i<Data.length; i++)
	{
		if(nochk.indexOf(Data.substring(i,i+1)) < 0) 
		{ 
			return true;
		}
	}
	return false ;
}

//영문과 숫자만 있는경우 false
function CheckEngNumPass(Data) 
{
	var nochk="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789"
	for (i=0; i<Data.length; i++)
	{
		if(nochk.indexOf(Data.substring(i,i+1)) < 0) 
		{ 
			return true;
		}
	}
	return false ;
}

//영문,숫자,특수기호 있는경우 false
function CheckAllPass(Data) 
{
	var nochk="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789 `~!@#$%^&*()_-+=|\\[]{}:;,<.>/?'\""
	for (i=0; i<Data.length; i++)
	{
		if(nochk.indexOf(Data.substring(i,i+1)) < 0) 
		{ 
			return true;
		}
	}
	return false ;
}




			 
//숫자만 사용했는지 체크
function isNum(str){
if(isEmpty(str)) return false;
for(var idx=0;idx < str.length;idx++){
    if(str.charAt(idx) < '0' || str.charAt(idx) > '9'){
        return false;
    }
}
return true;
}

//빈값인지 아닌지 판단
function isEmpty(pValue){
if( (pValue == "") || (pValue == null) || (pValue.length == 0)){
    return true;
}
return false;
}