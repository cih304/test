jQuery(function($){
	$.datepicker.regional['en'] = {
			dateFormat: 'yy-mm-dd',
			showOn: "button",
			buttonText: "Calendar",
			buttonImage: "/images/backimg/btn_day.gif",
			buttonImageOnly: true
	};
	$.datepicker.setDefaults($.datepicker.regional['en']);
});