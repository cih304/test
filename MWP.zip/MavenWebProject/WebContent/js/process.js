//<![CDATA[
function doAccept() {
	$('#processFrm').attr("action", "./setAccept").submit();
}

function doReject() {
	var	fm	= $('#processFrm').get(0);
	
	if(!fm.reject_comment.value) {
		alert("반려사유를 작성해 주세요.");
		fm.reject_comment.focus();
		return;
	}
	
	fm.action	= "./setReject";
	fm.submit();
}

function doCancel() {
	var fm	= $('#processFrm').get(0);
	
	if(!fm.reject_comment.value) {
		alert("승인취소 사유를 작성해 주세요.");
		fm.reject_comment.focus();
		return;
	}
	
	fm.action	= "./setCancel";
	fm.submit();
}

function doComplate() {
	$('#processFrm').attr("action", "./setComplate").submit();
}

function doMailSend(receiver_id , req_no, receiver_mail){
    if(confirm("VPN/서버접근 사용자 가이드를 발송 하시겠습니까?")) {
    	$.ajax({
    		type: "POST",
    		url: "./sendMail",
    		data: "&req_no=" + req_no + "&receiver_mail=" + receiver_mail + "&receiver_id=" + receiver_id,
    		dataType: "json",
    		async: false,
    		success:function(data) {
    			if(data.result) {
    				alert("메일전송을 완료 했습니다.");
    				location.reload();
    			} else
    				alert("메일전송중 오류가 발생 했습니다.");
    		},
    		fail:function() {
    			alert("데이터 통신중 오류가 발생했습니다.");
    		}
    	});
      
    }
	

}

function doSmsPopup(receiver_id, req_no , phone, e ){ 
	
	var event  = e || window.event;
	var Xcoor = event.screenX - 250;
	var Ycoor = event.screenY - 400;
	window.open("/popup/sms?receiver_id=" + receiver_id + "&req_no=" + req_no + "&phone=" + phone, "SmsPopup", "width=500 ,height=400, left=" + Xcoor + ", top="+ Ycoor + "status=no,scrollbars=no");

}

//]]>