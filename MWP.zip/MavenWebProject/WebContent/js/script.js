// JavaScript Document
// left menu

$(document).ready(function(){
	
	
	$('.lnb').tendina({
		animate: true,
		speed:200,
		onHover: false,
		hoverDelay:300,
		activeMenu: $('#on')
		});
	
	$('.lnb').find("a").each(function(){
		
		if($(this).text() == '')
			$(this).remove();
			
	});
	
	
});
