package com.test.web.index.controller;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import static io.github.seleniumquery.SeleniumQuery.$;

import com.mpatric.mp3agic.ID3v2;
import com.mpatric.mp3agic.InvalidDataException;
import com.mpatric.mp3agic.Mp3File;
import com.mpatric.mp3agic.UnsupportedTagException;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.RandomAccessFile;
import java.util.Iterator;
import java.util.concurrent.TimeUnit;
 
@SuppressWarnings("unused")
@Controller
public class IndexController {
	
	 private static WebDriver driver;
 
	 @RequestMapping("index")
	 public String index(){
		 /*iexplorer();
		 test();
		 after();*/
	  return "index";
	 }
	 
	 @RequestMapping("file")
	 public String file(){
	  return "fileUploadDrag";
	 }
	 
	 @SuppressWarnings("static-access")
	@RequestMapping("/file/upload")
	 public String upload(MultipartHttpServletRequest multipartHttpServletRequest) throws IOException, UnsupportedTagException, InvalidDataException{
		 
//		 String mp3Path = "C:\\마마무 - 넌 is 뭔들.mp3";
		 //String testPath = "C:\\TEST.mp3";
	//	 File tagetFile = getFileInfo(mp3Path);
		 
		 Iterator iter = multipartHttpServletRequest.getFileNames();
		 while(iter.hasNext()) {
			 MultipartFile mFile = multipartHttpServletRequest.getFile((String)iter.next());
			 System.out.println("파일명 :: " + mFile.getOriginalFilename());
			 /*File ffile = new File(mFile.getOriginalFilename());
			 mFile.transferTo(ffile);
			 System.out.println(" #File Name ==> " + ffile.getName());
			 System.out.println(" #File Path ==> " + ffile.getPath());
			 System.out.println(" #File AbsolutePath ==> " + ffile.getAbsolutePath());
			 System.out.println(" #File CanonicalPath ==> " + ffile.getCanonicalPath());
			 
			 sameFileCheck(tagetFile, ffile);*/
		 }
		 return "fileUploadDrag";
	 }
	 
	 
	 public static File getFileInfo(String filePath) throws UnsupportedTagException, InvalidDataException, IOException {
		 String fileExt = "";	
		 Mp3File mp3file = new Mp3File(filePath);
	 	 if(mp3file.hasId3v2Tag()) {
			ID3v2 tag = mp3file.getId3v2Tag();
			byte albumCoverData[] = tag.getAlbumImage();
			if(null != albumCoverData) {
				//Cover Image추출
				String mimeType = tag.getAlbumImageMimeType();
				fileExt =  mimeTypeCovert(mimeType);
				RandomAccessFile file = new RandomAccessFile("c:\\ori-Cover"+mimeTypeCovert(mimeType), "rw");
				file.write(albumCoverData);
				file.close();
			}
		}
		return new File("c:\\ori-Cover" + fileExt); 
	}
	 
	 public static String mimeTypeCovert(String mimeType) {
			String extention = ".";
			if("image/bmp".equals(mimeType)) {
				extention += "bmp";
			}else if("image/jpeg".equals(mimeType)) {
				extention += "jpg";
			}else if("image/gif".equals(mimeType)) {
				extention += "gif";
			}else if("image/x-icon".equals(mimeType)) {
				extention += "ico";
			}else {
				extention = "";
			}
			return extention;
	}
	 
	 
	 /**
	 * 같은파일인지 체크
	 * @param file1
	 * @param file2
	 * @return
	 * @throws IOException
	 */
	public static boolean sameFileCheck(File file1, File file2) throws IOException {
		 boolean flag = true;
		 int byte1 = -1;
		 int byte2 = -1;
		 InputStream is1 = file1.toURL().openConnection().getInputStream();
		 InputStream is2 = file2.toURL().openConnection().getInputStream();
		 if(is1 != null && is2 != null) {
			 while((byte1 = is1.read()) != -1 && (byte2 = is2.read()) != -1) {
				 if(byte1 != byte2) {
					 flag = false;
					 break;
				 }
			 }
		 }
		 if(flag) {
			System.out.println("같은파일"); 
		 }else {
			 System.out.println("byte1 ==> " + byte1 + " : byte2 ==> " + byte2);
			 System.out.println("다른파일");
		 }
		 return flag;
	 }
	 
	 @BeforeClass
	 public static void iexplorer() {
		 System.setProperty("webdriver.ie.driver", "C:\\IEDriverServer.exe");
		 
		 DesiredCapabilities ieCapabilities = DesiredCapabilities.internetExplorer(); 
		 ieCapabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
		 
		 driver = new InternetExplorerDriver(ieCapabilities);
		 driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		 driver.get("http://naver.com");
		 
		 
		 /*$.driver().useInternetExplorer();
		 $.driver().use(new InternetExplorerDriver(ieCapabilities));
		 $.driver().useInternetExplorer().withCapabilities(ieCapabilities);*/
		 
		 driver.get("http://naver.com");
		 
		 //driver.findElement(By.id("svc.kin")).click(); 
		 
	 }
	 
	 @Test
	 public static void test() {
		 driver.findElement(By.id("id")).sendKeys("id");
		 driver.findElement(By.className("btn_login")).click();
	 }
	 
	 @AfterClass
	 public static void after() {
		 driver.quit();
	 }
	 
	 
 
}