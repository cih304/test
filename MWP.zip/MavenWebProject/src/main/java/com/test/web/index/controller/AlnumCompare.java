package com.test.web.index.controller;

import java.io.File;

public class AlnumCompare implements java.util.Comparator<File> {
	private enum CHUNK_TYPE { CHUNK_ALPHA, CHUNK_DIGIT };
	
	private static class ALNUM_CHUNK
	{
		public CHUNK_TYPE type;
		public String data;
		
		public ALNUM_CHUNK( String _data, CHUNK_TYPE _type ) {
			data = _data;
			type = _type;
		}
	}
	
	public ALNUM_CHUNK getChunk( String origin, int from, int end ) {
		if( from >= end ) return null;	///> Throw Exception Generally
		
		boolean isDigit = Character.isDigit( origin.charAt(from) );
		StringBuffer buf = new StringBuffer();
		char ch;
		
		while( from < end ) {
			ch = origin.charAt(from);
			if( isDigit != Character.isDigit(ch) ) {
				break;
			}
			buf.append( ch );
			from++;
		}
		
		return new ALNUM_CHUNK( buf.toString(), isDigit ? CHUNK_TYPE.CHUNK_DIGIT : CHUNK_TYPE.CHUNK_ALPHA );
	}
	
	@Override
	public int compare( File file1, File file2 )
	{
		int diff = 0;
		
		int i = 0, 
		    j = 0;
		
		String str1 = file1.getName();
		String str2 = file2.getName();
		
		int len1 = str1.length(),
		    len2 = str2.length();
		
		ALNUM_CHUNK chunk1 = null, 
				    chunk2 = null;
		
		while( i < len1 && j < len2 ) {
			
			chunk1 = getChunk( str1, i, len1 );
			chunk2 = getChunk( str2, j, len2 );
			
			if( chunk1.type == CHUNK_TYPE.CHUNK_DIGIT && chunk2.type == CHUNK_TYPE.CHUNK_DIGIT ) {
				diff = Integer.parseInt( chunk1.data ) - Integer.parseInt( chunk2.data );
			}
			else {
				diff = chunk1.data.compareToIgnoreCase( chunk2.data );
			}
			
			if( diff != 0 ) {
				return diff;
			}

			i += chunk1.data.length();
			j += chunk2.data.length();
		}
		
		return len1 - len2;
	}
}