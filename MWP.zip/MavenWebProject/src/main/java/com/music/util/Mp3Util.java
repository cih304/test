package com.music.util;

import java.io.BufferedWriter;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStreamWriter;
import java.io.RandomAccessFile;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.apache.tika.Tika;

import com.mpatric.mp3agic.ID3v2;
import com.mpatric.mp3agic.InvalidDataException;
import com.mpatric.mp3agic.Mp3File;
import com.mpatric.mp3agic.NotSupportedException;
import com.mpatric.mp3agic.UnsupportedTagException;
import com.test.web.index.controller.AlnumCompare;

public class Mp3Util {
	
	
	/**
	 * 처리예외 파일명 
	 */
	private final static String[] excludeFileNameArr = new String[] {
		"[ori]FileName", "[ori]Cover", "[ori]Log"
	};
	
	/**
	 * 장르 목록
	 */
	private final static String[] genreList = new String[] {
			"Blues", "Classic Rock", "Country", "Dance", "Disco", "Funk", "Grunge", "Hip-Hop", "Jazz", "Metal", "New Age",
			"Oldies", "Other", "Pop", "R&B", "Rap", "Reggae", "Rock", "Techno", "Industrial", "Alternative", "Ska", "Death Metal",
			"Pranks", "Soundtrack", "Euro-Techno", "Ambient", "Trip-Hop", "Vocal", "Jazz+Funk", "Fusion", "Trance", "Classical",
			"Instrumental", "Acid", "House", "Game", "Sound Clip", "Gospel", "Noise", "AlternRock", "Bass", "Soul", "Punk",
			"Space", "Meditative", "Instrumental Pop", "Instrumental Rock", "Ethnic", "Gothic", "Darkwave", "Techno-Industrial",
			"Electronic", "Pop-Folk", "Eurodance", "Dream", "Southern Rock", "Comedy", "Cult", "Gangsta", "Top 40", "Christian Rap",
			"Pop/Funk", "Jungle", "Native American", "Cabaret", "New Wave", "Psychadelic", "Rave", "Showtunes", "Trailer",
			"Lo-Fi", "Tribal", "Acid Punk", "Acid Jazz", "Polka", "Retro", "Musical", "Rock & Roll", "Hard Rock", "Folk",
			"Folk-Rock", "National Folk", "Swing", "Fast Fusion", "Bebob", "Latin", "Revival", "Celtic", "Bluegrass", "Avantgarde",
			"Gothic Rock", "Progressive Rock", "Psychedelic Rock", "Symphonic Rock", "Slow Rock", "Big Band", "Chorus", "Easy Listening",
			"Acoustic", "Humour", "Speech", "Chanson", "Opera", "Chamber Music", "Sonata", "Symphony", "Booty Bass",
			"Primus", "Porn Groove", "Satire", "Slow Jam", "Club", "Tango", "Samba", "Folklore", "Ballad", "Power Ballad",
			"Rhythmic Soul", "Freestyle", "Duet", "Punk Rock", "Drum Solo", "A capella", "Euro-House", "Dance Hall"
	};

	/**
	 * 파일명 변환
	 * @param path
	 * @param header
	 * @param digit
	 * @param mode
	 * @return
	 * @throws IOException 
	 * @throws InvalidDataException 
	 * @throws UnsupportedTagException 
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public static Map<String, Object> fileNameChange(String path, String[] afterArr, String header, int digit, String mode) throws UnsupportedTagException, InvalidDataException, IOException {
		File file = new File(path);
		File[] fileList = file.listFiles();
		Arrays.sort(fileList, new AlnumCompare());	//숫자를 고려한 파일정렬(윈도우 탐색기 정렬)
		String msg = "Success~!!";
		String fileType = "";
		StringBuilder sb1 = new StringBuilder(); 
		StringBuilder sb2 = new StringBuilder();
		StringBuilder sb3 = new StringBuilder();
		int cnt = 0;
		int runCnt = 0;
		List<String> fileTypeList = new ArrayList();
		List<Map<String, String>> virtualList = new ArrayList<Map<String, String>>();
		Map<String, Object> resultMap = new HashMap<String, Object>();
		
		if(!"VIRTUAL".equals(mode) && !"RUN".equals(mode)) {  
			msg = "MODE를 확인해주세요.";
		
		}else {
			if(null != file && file.exists()) {
				for(int i=0; i<fileList.length; i++) {
					if(fileList[i].isDirectory()) continue;
					String fileFullName = fileList[i].getName();
					String saveFileName = "";
					String formatSeq = "";
					String fileExtention = "";	//확장자
					boolean exceptFlag = false;
					
					//예외처리 파일명 제외
					for(String exclude : excludeFileNameArr) {
						if(fileFullName.startsWith(exclude)) {
							exceptFlag = true;
							break;
						}
					}
					if(exceptFlag) continue;
					
					int seq = cnt+1;
					int zeroCnt = digit - Integer.toString(seq).length();
					for(int j=0; j<zeroCnt; j++) {
						formatSeq += "0";
					}
					formatSeq += seq;
					fileExtention = fileFullName.substring(fileFullName.lastIndexOf(".")+1).toLowerCase();
					
					if("mp3".equals(fileExtention)) {
						fileType = StringUtils.trimToEmpty(getFileInfo(fileList[i].getPath()));
					}else {
						fileType = fileExtention;
						if("flac".equals(fileType.toLowerCase())) fileType = fileType.toUpperCase();
					}
					
					if(!"".equals(fileType) && !fileTypeList.contains(fileType)) {
						fileTypeList.add(fileType);
					}
					
					if(afterArr != null && afterArr.length > 0) {
						saveFileName = header + formatSeq + ". " + afterArr[cnt++] + "." + fileExtention;
					}else {
						saveFileName = header + formatSeq + "." + fileExtention;
					}
					
					sb1.append(fileFullName+"\r\n");
					Map<String, String> pMap = new HashMap<String, String>();
					pMap.put("oriFileName", fileFullName);
					pMap.put("saveFileName", saveFileName);
					virtualList.add(pMap);
					
					if("RUN".equals(mode)) {
						fileList[i].renameTo(new File(path + File.separator + saveFileName));
						++runCnt;
					}
				}
				
				//String trackCnt = ""+cnt+"/"+afterArr.length;
				String trackCnt = ""+afterArr.length;
				resultMap.put("trackCnt", trackCnt);
				
				if("VIRTUAL".equals(mode) || "RUN".equals(mode)) {
					sb2 = showFileStatus(virtualList, mode);
					for(int i=0; i<fileTypeList.size(); i++) {
						sb3.append((i>0 ? " + " : "") + fileTypeList.get(i));
					}
					
					if("RUN".equals(mode)) {
						msg = " - 총 " + runCnt + "개 파일변환 성공";
						sb2.append(msg);
						try {
							textFileWrite(sb1.toString(), path, "ORI");
							textFileWrite(sb2.toString(), path, "LOG");
						} catch (IOException e) {
							System.out.println("파일저장시 에러 == \n" + e.getMessage());
						}
					}
				}
				
			}else {
				msg = "파일이 존재하지 않습니다.";
			}
		}

		resultMap.put("msg", msg);
		resultMap.put("fileType", sb3.toString());
		resultMap.put("virtualList", virtualList);
		
		return resultMap;
	}
	
	
	/**
	 * 파일명 진행상태 출력
	 * @param virtualList
	 * @param mode
	 */
	public static StringBuilder showFileStatus(List<Map<String, String>> virtualList, String mode) {
		StringBuilder logSb = new StringBuilder();
		if(null != virtualList && !virtualList.isEmpty()) {
			int cnt = 1;
			String headerStr = "";
			if("VIRTUAL".equals(mode)) {
				headerStr = "가상 파일변경 시나리오";
			}else if("RUN".equals(mode)) {
				headerStr = "아래와 같이 변경 완료 되었습니다";
			}
			
			logSb.append("## [" + headerStr + "] ###################################\r\n");
			for(Map<String,String> vMap : virtualList) {
				String ori = (String)vMap.get("oriFileName");
				String save = (String)vMap.get("saveFileName"); 
				if(cnt==1) logSb.append("  ---------------------------------------------------\r\n");
				logSb.append(cnt++ + ".\t원본파일명 : " + ori + "\r\n");
				logSb.append("\t변경파일명 : " + save + "\r\n");
				logSb.append("  ---------------------------------------------------\r\n");
			}
			logSb.append("#########################################################\r\n");
		}
		return logSb;
	}
	
	
	/**
	 * 정보 추출
	 * @param path
	 * @throws UnsupportedTagException
	 * @throws InvalidDataException
	 * @throws IOException
	 */
	public static String getFileInfo(String filePath) throws UnsupportedTagException, InvalidDataException, IOException {
		Mp3File mp3file = new Mp3File(filePath);
		
		System.out.println("Length of this mp3 is: " + mp3file.getLengthInSeconds() + " seconds");
		System.out.println("Bitrate: " + mp3file.getBitrate() + " kbps " + (mp3file.isVbr() ? "(VBR)" : "(CBR)"));
		System.out.println("Sample rate: " + mp3file.getSampleRate() + " Hz");
		
		if(mp3file.hasId3v2Tag()) {
			ID3v2 tag = mp3file.getId3v2Tag();
			System.out.println("Track: " + tag.getTrack());
			System.out.println("Artist: " + tag.getArtist());
			System.out.println("Title: " + tag.getTitle());
			System.out.println("Album: " + tag.getAlbum());
			System.out.println("Year: " + tag.getYear());
			System.out.println("Genre: " + tag.getGenre() + " (" + tag.getGenreDescription() + ")");
			System.out.println("Comment: " + tag.getComment());
			System.out.println("Composer: " + tag.getComposer());
			System.out.println("Publisher: " + tag.getPublisher());
			System.out.println("Original artist: " + tag.getOriginalArtist());
			System.out.println("Album artist: " + tag.getAlbumArtist());
			System.out.println("Copyright: " + tag.getCopyright());
			System.out.println("URL: " + tag.getUrl());
			System.out.println("Encoder: " + tag.getEncoder());
			
			byte albumCoverData[] = tag.getAlbumImage();
			String fileExt = "";
			if(null != albumCoverData) {
				System.out.println("Have album image data, length: " + getDataUnit(albumCoverData.length));
				System.out.println("Album image mime type: " + tag.getAlbumImageMimeType());
				
				//Cover Image추출
				String mimeType = tag.getAlbumImageMimeType();
				fileExt =  mimeTypeConvert(mimeType);
				RandomAccessFile file = new RandomAccessFile("c:\\ori-Cover"+mimeTypeConvert(mimeType), "rw");
				file.write(albumCoverData);
				file.close();
				
				//WEB화면에 출력 (테스트하지 않음)
				//String contentType = "images/"+fileExt;
				//response.setContentType("");
				byte[] buffer = new byte[1024];
				InputStream is = new ByteArrayInputStream(albumCoverData, 0, albumCoverData.length);
				int length = -1;
				while((length = is.read(buffer)) != -1) {
					//out.write(buffer, 0, albumCoverData.length);
				}
				
			}
			
			File file = new File("c:\\ori-Cover" + fileExt);
			System.out.println(file.getName());
			
			
			
			
			
			//Cover Image저장
			/*File targetImgFile = new File("C:\\change.jpg");
			String targetImgMimeType = new Tika().detect(targetImgFile);
			RandomAccessFile file = new RandomAccessFile(targetImgFile, "r");
			byte imgSaveByte[] = new byte[(int)file.length()];
			file.seek(1000);
			file.read(imgSaveByte);
			file.close();
			
			tag.setAlbumImage(imgSaveByte, targetImgMimeType);
			try {
				mp3file.save("c:\\test.mp3");
			} catch (NotSupportedException e) {
				e.printStackTrace();
			}*/
		}
		return mp3file.getBitrate() + "k";
	}
	
	/**
	 * 파일정보 저장
	 * @param filePath
	 * @return
	 * @throws Exception
	 */
	public static String setFileInfo(String filePath) throws Exception {
		
		Mp3File mp3file = new Mp3File(filePath);
		
		if(mp3file.hasId3v2Tag()) {
			ID3v2 tag = mp3file.getId3v2Tag();
			tag.setArtist("");
			tag.setTitle("");
			tag.setAlbum("");
			tag.setYear("");
			tag.setGenre(1);
			tag.setTrack("");
			tag.setPublisher("");
			tag.setComment("");
			
			try {
				mp3file.save(filePath);
			} catch (NotSupportedException e) {
				e.printStackTrace();
			}
			
			/*byte albumCoverData[] = tag.getAlbumImage();
			if(null != albumCoverData) {
				System.out.println("Have album image data, length: " + getDataUnit(albumCoverData.length));
				System.out.println("Album image mime type: " + tag.getAlbumImageMimeType());
				
				//Cover Image추출
				String mimeType = tag.getAlbumImageMimeType();
				RandomAccessFile file = new RandomAccessFile("c:\\ori-Cover"+mimeTypeCovert(mimeType), "rw");
				file.write(albumCoverData);
				file.close();
			}*/
			
			//Cover Image저장
			/*File targetImgFile = new File("C:\\change.jpg");
			String targetImgMimeType = new Tika().detect(targetImgFile);
			RandomAccessFile file = new RandomAccessFile(targetImgFile, "r");
			byte imgSaveByte[] = new byte[(int)file.length()];
			file.seek(1000);
			file.read(imgSaveByte);
			file.close();
			
			tag.setAlbumImage(imgSaveByte, targetImgMimeType);
			try {
				mp3file.save("c:\\test.mp3");
			} catch (NotSupportedException e) {
				e.printStackTrace();
			}*/
			
		}
		
		
		return "";
	}
	
	
	/**
	 * 텍스트 파일 저장
	 * @return
	 * @throws IOException 
	 */
	public static boolean textFileWrite(String content, String path, String type) throws IOException {
		String saveFileNm = "";
		if("ORI".equals(type)) {
			saveFileNm = "[ori]FileName.txt";
		}else if("LOG".equals(type)) {
			saveFileNm = "[ori]Log.txt";
		}
		File saveFolder = new File(path);
		BufferedWriter bw = null;
		if(saveFolder.exists() && saveFolder.isDirectory()) {
			try {
				File file = new File(path + File.separator + saveFileNm);
				GregorianCalendar today = new GregorianCalendar();
				String tab = "===========================================================\r\n";
				String nowDate = "[" + new SimpleDateFormat("yyyy년MM월dd일 HH시mm분").format(today.getTime()) + "]\r\n";
				content = ((file.exists() && file.isFile()) ? "\r\n\r\n" : "") + tab + nowDate + tab + content;
				
				bw = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(file, true), "euc-kr"));
				bw.write(content);
				bw.flush();
				return true;
			}finally {
				bw.close();
			}
		}
		return false;
	}
	
	/**
	 * 파일 용량 구하기
	 * @param dataSize
	 * @return
	 */
	public static String getDataUnit(long dataSize) {
		String unit[] = {"Byte", "KB", "MB", "GB", "TB"};
		BigDecimal capacity = new BigDecimal(dataSize);
		capacity = capacity.divide(new BigDecimal("1024")).setScale(1, BigDecimal.ROUND_HALF_UP);
		String cap = capacity.toString();
		cap = cap.substring(0, cap.indexOf("."));
		int unitCnt = (int)Math.floor(Integer.parseInt(""+cap.length())/3);
		return capacity + unit[unitCnt];
	}
	
	/**
	 * MimeType으로 그림파일 확장자 확인
	 * @param mimeType
	 * @return
	 */
	public static String mimeTypeConvert(String mimeType) {
		String extention = ".";
		if("image/bmp".equals(mimeType)) {
			extention += "bmp";
		}else if("image/jpeg".equals(mimeType)) {
			extention += "jpg";
		}else if("image/gif".equals(mimeType)) {
			extention += "gif";
		}else if("image/png".equals(mimeType)) {
			extention += "png";
		}else if("image/x-icon".equals(mimeType)) {
			extention += "ico";
		}else {
			extention = "";
		}
		return extention;
	}
	
	public static void fileImageWrite(String path) throws FileNotFoundException {
		InputStream is = null;
		if(!path.equals("")) {
			if(new File(path).isFile()) {
				is = new FileInputStream(path);
				
			}
		}
	}
	
	public static void main(String[] args) throws UnsupportedTagException, InvalidDataException, IOException {
		//String path = "C:\\test";
		//String header = "";
		//fileNameChange(path, null, header, 2, "VIRTUAL");

		String mp3Path = "C:\\마마무 - 넌 is 뭔들.mp3";
		//String testPath = "C:\\TEST.mp3";
		getFileInfo(mp3Path);
		System.out.println("-------------------------");
		
		//1.파일명 변경 시 원본 파일명 [ori]FileName.txt 으로 저장
		//2.원본 그림파일 추출(체크) 후 체크된 커버 이미지파일만 저장 [ori]Cover
		//3.Log파일 [ori]Log.txt
	}
	
}
