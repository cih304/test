package com.music.service;

import java.awt.Image;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.swing.ImageIcon;

import org.apache.commons.lang3.StringUtils;
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.HttpResponseException;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.BasicResponseHandler;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.tika.Tika;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import org.springframework.stereotype.Service;

import com.mpatric.mp3agic.ID3v2;
import com.mpatric.mp3agic.InvalidDataException;
import com.mpatric.mp3agic.Mp3File;
import com.mpatric.mp3agic.UnsupportedTagException;
import com.music.util.Mp3Util;
import com.test.web.index.controller.AlnumCompare;

@Service
public class MusicService {

	private static Mp3Util mp3Util = new Mp3Util();
	
	private static final String BUGS_URL = "bugs.co.kr";  
	private static final String MELON_URL = "melon.com";  

	@SuppressWarnings("static-access")
	public static Map<String, Object> fileNameChange(String path, String[] afterArr, String header, String mode) throws UnsupportedTagException, InvalidDataException, IOException {
		return mp3Util.fileNameChange(path, afterArr, header, 2, mode);
	}
	
	/**
	 * 앨범정보
	 * @param url
	 * @param type
	 * @return
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public static List<Map<String, Object>> getAlbumInfo(String url) {
		String html = getUrlDocument(url);
		//System.out.println("HTML ==== \n" + html);
		Document doc = Jsoup.parse(html);
		List<Map<String, Object>> albumList = new ArrayList<Map<String, Object>>();
		Map<String, Object> albumMap = null;
		
		if(url.indexOf(BUGS_URL) > -1) {
			//songName List
			Elements rows = doc.select("p.title>a");
			for(Element row : rows) {
				albumMap = new HashMap<String, Object>();
				String songName = StringUtils.trimToEmpty(row.attr("title")).replace(" 듣기 -새창", "");
				albumMap.put("songName", songName);
				albumList.add(albumMap);
			}
			
			//album info
			albumMap = new HashMap<String, Object>();
			Elements infos = doc.select("table.info>tbody>tr");
			for(int i=0; i<infos.size(); i++) {
				String infoKey = StringUtils.trimToEmpty(infos.get(i).select("th").text());
				String infoVal = StringUtils.trimToEmpty(infos.get(i).select("td").text());
				albumMap.put(infoKey, infoVal);
			}
			albumList.add(albumMap);
			
		}else if(url.indexOf(MELON_URL) > -1) {
			Elements trRow = doc.select("tbody>tr");
			for(Element tr : trRow) {
				Map pMap = null;
				String songName = "";
				Elements rows = tr.select("div.ellipsis>a");
				for(Element row : rows) {
					albumMap = new HashMap<String, Object>();
					String href = StringUtils.trimToEmpty(row.attr("href"));
					if(href.indexOf("melon.link.goSongDetail") > -1) {
						String songId = StringUtils.trimToEmpty(href.substring(href.indexOf("'")+1, href.lastIndexOf("'")));
						if(!"".equals(songId)) {
							String detailUrl = "http://www.melon.com/song/detail.htm?songId=" + songId;
							String detailHtml = getUrlDocument(detailUrl);
							Document detailDoc = Jsoup.parse(detailHtml);
							//String sname = StringUtils.trimToEmpty(detailDoc.select("div.wrap_thumb>a").attr("title")); 
							Elements detailRows = detailDoc.select("div.box_lyric>dl");
							pMap = new HashMap();
							for(Element detRow : detailRows) {
								String detInfoKey = StringUtils.trimToEmpty(detRow.select("dt").text());
								String detInfoVal = StringUtils.trimToEmpty(detRow.select("dd>a").attr("title")).replace(" (", "(");
								if(pMap.containsKey(detInfoKey)) {
									detInfoVal = (String)pMap.get(detInfoKey) + ", " + detInfoVal;
								}
								pMap.put(detInfoKey, detInfoVal);
							}
						}
					}
					if(href.indexOf("melon.play.playSong") > -1) {
						songName = StringUtils.trimToEmpty(row.attr("title"));
					}
				}
				albumMap.put("songName", songName);
				albumMap.put("songDetail", pMap);
				albumList.add(albumMap);
			}
			
			albumMap = new HashMap<String, Object>();  
			String albumName = StringUtils.trimToEmpty(doc.select("p.albumname").html());
			if(!"".equals(albumName) && albumName.indexOf(">") > -1) {
				albumName = albumName.substring(albumName.lastIndexOf(">")+1).trim();
			}
			String albumType = StringUtils.trimToEmpty(doc.select("p.albumname>span.gubun").text().replace("[","").replace("]",""));
			albumMap.put("albumName", albumName);
			albumMap.put("albumType", albumType);
			
			Elements dts = doc.select("dl.song_info>dt");
			Elements dds = doc.select("dl.song_info>dd");
			
			for(int i=0; i<dts.size(); i++) {
				String infoKey = StringUtils.trimToEmpty(dts.get(i).text());
				String infoVal = StringUtils.trimToEmpty(dds.get(i).text());
				boolean infoFlag = false;
				if(!"".equals(infoKey)) {
					if("아티스트".equals(infoKey)) {
						infoKey = "singer";		
						infoFlag = true;
					}else if("발매일".equals(infoKey)) {
						infoKey = "date";
						infoFlag = true;
					}else if("발매사".equals(infoKey)) {
						infoKey = "publisher";
						infoFlag = true;
					}else if("장르".equals(infoKey)) {
						infoKey = "genre";
						infoFlag = true;
					}
					
					if(infoFlag) {
						albumMap.put(infoKey, infoVal);
					}
				}
			}
			albumList.add(albumMap);
		}
		return albumList;
	}
	

	/**
	 * URL 주소의 HTML을 String으로 반환
	 * @param url
	 * @return
	 */
	@SuppressWarnings({ "unused", "rawtypes" })
	public static String getUrlDocument(String url) {
		List list = new ArrayList();
		Map pMap = new HashMap();
		String result = "";

		HttpClient httpClient = HttpClientBuilder.create().build();
		HttpGet httpget = new HttpGet(url);
		try {
			result = httpClient.execute(httpget, new BasicResponseHandler() {
				@Override
				public String handleResponse(HttpResponse response) throws HttpResponseException, IOException {
					return super.handleResponse(response);
				}
			});
		} catch (ClientProtocolException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return result;
	}
	
	/**
	 * 이미지파일 리스트
	 * @param path
	 * @param classPath
	 * @return
	 * @throws UnsupportedTagException
	 * @throws InvalidDataException
	 * @throws IOException
	 */
	public static List<Map> fileImgList(String path, String classPath) throws UnsupportedTagException, InvalidDataException, IOException {
		List<Map> fileImgList = new ArrayList<Map>();
		String coverPath = "";
		File file = new File(path);
		File[] fileList = file.listFiles();
		Arrays.sort(fileList, new AlnumCompare());	//숫자를 고려한 파일정렬(윈도우 탐색기 정렬)
		
		if(null != file && file.exists()) {
			Map pMap = null;
			//폴더삭제
			File mkdir = new File(classPath + File.separator + "Tmp");
			if(mkdir.exists() && mkdir.isDirectory()) {
				File[] listFile = mkdir.listFiles();
				if(listFile.length > 0) {
					for(File f : listFile) {
						f.delete();
					}
				}
			}else {
				mkdir.mkdir();
			}
			
			for(int i=0; i<fileList.length; i++) {
				pMap = new HashMap();
				String filePath = fileList[i].getPath();
				if(new File(filePath).isDirectory()) continue;
				Mp3File mp3file = new Mp3File(filePath);
				
				//파일임시저장
				if(mp3file.hasId3v2Tag()) {
					ID3v2 tag = mp3file.getId3v2Tag();
					byte albumCoverData[] = tag.getAlbumImage();
					String fileExt = "";
					if(null != albumCoverData) {
						String mimeType = tag.getAlbumImageMimeType();
						fileExt = mp3Util.mimeTypeConvert(mimeType);
						coverPath = classPath + File.separator + "Tmp" + File.separator + "ori-Cover" + (i+1) + fileExt;
						System.out.println("coverPath ==> " + coverPath);
						RandomAccessFile raf = new RandomAccessFile(coverPath, "rw");
						raf.write(albumCoverData);
						raf.close();
					}
					
					if(new File(coverPath).exists() && new File(coverPath).isFile()) {
						Image img = new ImageIcon(coverPath).getImage();
						pMap.put("coverSize", img.getWidth(null) + "x" + img.getHeight(null));
						pMap.put("coverCapacity", mp3Util.getDataUnit(new File(coverPath).length()));
						pMap.put("coverPath", "ori-Cover" + (i+1) + fileExt);
					}
				}
				fileImgList.add(pMap);
			}
		}
		return fileImgList;
	}
	
	/**
	 * 곡목리스트
	 * @param sList
	 * @return
	 */
	public static List<String> getSongList(List<Map<String, Object>> sList) {
		List<String> list = null;
		if(sList!=null && !sList.isEmpty()) {
			list = new ArrayList<String>();
			for(Map map : sList) {
				String songNm = StringUtils.trimToEmpty(map.get("songName")!=null?(String)map.get("songName") : "");
				if(!songNm.equals("")) 
					list.add(songNm);
			}
		}
		return list;
	}
	
	/**
	 * 배열의 최대값 구하기
	 * @param sizeArr
	 * @return
	 */
	public static int getMaxSize(int[] sizeArr) {
		int maxSize = -1;
		if(sizeArr!= null) {
			for(int i=0; i<sizeArr.length; i++) {
				if(maxSize < sizeArr[i]) maxSize = sizeArr[i];
			}
		}
		return maxSize;
	}
	
	/**
	 * 같은곡목 체크
	 * @param songNmList
	 * @param cnt
	 * @return
	 */
	public static String getSongListStatus(String[] songNmList, int cnt) {
		StringBuilder sb = new StringBuilder();
		String songNm1 = "";
		String songNm2 = "";
		boolean sameFlag = true;
		if(songNmList!=null && songNmList.length > 0) {
			for(int i=0; i<songNmList.length; i++) {
				if(songNm1.equals("")) {
					songNm1 = songNmList[i];
				}else if(!songNm1.equals(songNmList[i])) {
					sameFlag = false;
					songNm2 = songNmList[i];
				}
			}
		}
		if(songNm1.equals("")) return "";
		if(sameFlag) {
			System.out.println("["+(cnt+1)+"] " + songNm1 + "\t\t............OK.");
			sb.append("["+(cnt+1)+"] " + songNm1 + "\t\t............OK.");
		}else {
			System.out.println("["+(cnt+1)+"] " + songNm1 + " : " + songNm2 + "\t\t............NO.");
			sb.append("["+(cnt+1)+"] " + songNm1 + " : " + songNm2 + "\t\t............NO.");
		}
		
		return sb.toString();
	}
	
	
	/**
	 * 파일복사
	 * @param targetFile
	 * @param destFile
	 * @return
	 */
	public static boolean fileCopy(String targetFile, String destFile) {
		boolean resultFlag = true;
		
		try {
			FileInputStream fis = new FileInputStream(new File(targetFile));
			FileOutputStream fos = new FileOutputStream(new File(destFile));
			int data = 0;
			while((data=fis.read()) != -1) {
				fos.write(data);
			}
			fis.close();
			fos.close();
		}catch (Exception e) {
			e.printStackTrace();
			resultFlag = false;
		}
		
		return resultFlag;
	}
	
	/**
	 * 임시저장소 경로 구하기
	 * @param classPath
	 * @param targetPath
	 * @param saveFileName
	 * @return
	 * @throws IOException
	 */
	@SuppressWarnings("static-access")
	public static String parsePath(String classPath, String targetPath, String saveFileName) throws IOException {
		String saveFullPath = "";
		File targetFile = new File(targetPath);
		if(targetFile.isFile()) {
			saveFullPath = classPath + "Tmp" + File.separator;
			if("".equals(saveFileName)) {
				saveFullPath += targetPath;
			}else {
				String mimeType = mp3Util.mimeTypeConvert(new Tika().detect(targetFile));
				saveFullPath += saveFileName + mimeType;
			}
		}
		return saveFullPath;
	}
	
	public static void main(String[] args) {
		String url = "http://www.melon.com/album/detail.htm?albumId=2653811";
		List<Map<String, Object>> list1 = getAlbumInfo(url);
		for(Map map : list1) {
			System.out.println(map.toString());
		}
		String url2 = "http://music.bugs.co.kr/album/20010529";
		List<Map<String, Object>> list2 = getAlbumInfo(url2);
		for(Map map : list2) {
			System.out.println(map.toString());
		}
		
		//리스트 뽑기
		List<String> songNmList1 = getSongList(list1);
		List<String> songNmList2 = getSongList(list2);
		int songNmListSize1 = songNmList1.size();
		int songNmListSize2 = songNmList2.size();
		System.out.println("총 리스트1갯수 == > " + songNmListSize1);
		System.out.println("총 리스트2갯수 == > " + songNmListSize2);
		int maxSize = getMaxSize(new int[]{songNmListSize1, songNmListSize2});
		for(int i=0; i<maxSize; i++) {
			String songNm1 = "";
			String songNm2 = "";
			if(songNmList1 != null && songNmListSize1 > 0) {
				if(songNmListSize1 > i)
					songNm1 = StringUtils.trimToEmpty(songNmList1.get(i)!=null ? songNmList1.get(i) : "");
			}
			if(songNmList2 != null && songNmListSize2 > 0) {
				if(songNmListSize2 > i)
					songNm2 = StringUtils.trimToEmpty(songNmList2.get(i)!=null ? songNmList2.get(i) : "");
			}
			
			getSongListStatus(new String[]{songNm1, songNm2}, i);
		}
		
	}
	
}
