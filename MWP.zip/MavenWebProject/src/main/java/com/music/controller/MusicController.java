package com.music.controller;

import java.awt.Image;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.RandomAccessFile;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletContext;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.swing.ImageIcon;

import org.apache.commons.lang3.StringUtils;
import org.apache.tika.Tika;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.mpatric.mp3agic.ID3v2;
import com.mpatric.mp3agic.InvalidDataException;
import com.mpatric.mp3agic.Mp3File;
import com.mpatric.mp3agic.UnsupportedTagException;
import com.music.service.MusicService;
import com.music.util.Mp3Util;
import com.test.web.index.controller.AlnumCompare;
 
@Controller
public class MusicController {
	
	@Autowired
	MusicService musicService;
	
	//@Autowired
    //ServletContext context;
	
	private Mp3Util mp3util;
	//private final String CLASS_PATH = context.getRealPath("/"); 
	
	@RequestMapping("music")
	public String music(ModelMap model) {
		List allcount = new ArrayList();
		for(int i=0; i<15; i++) allcount.add(i);
		
		model.addAttribute("allcount",allcount);
		model.addAttribute("url", "http://music.bugs.co.kr/album/20010529");
		
		return "music";
	}
	
	@SuppressWarnings({ "unchecked", "rawtypes", "static-access" })
	@RequestMapping("music/trans")
	public String musicTrans(final HttpServletRequest req, HttpServletResponse res, ModelMap model) throws UnsupportedTagException, InvalidDataException, IOException {
		String CLASS_PATH = req.getSession().getServletContext().getRealPath("/");
		String path = req.getParameter("path");
		String url = req.getParameter("url");
		String beforeText = req.getParameter("beforeText").trim();
		String afterText = req.getParameter("afterText").trim();
		String mode = req.getParameter("mode");
		String afterArr[] = null;
		Map<String, Object> infoMap = new HashMap<String, Object>(); 
		List<Map<String, Object>> musicList = null;
		
		if(null != url && !"".equals(url)) {
			musicList = musicService.getAlbumInfo(url);
			StringBuilder sb = new StringBuilder();
			int cnt = 1;
			for(Map map : musicList) {
				if(map.get("songName") != null) {
					sb.append((cnt++>1 ? "\r\n" : "") + StringUtils.trimToEmpty((String)map.get("songName")));
				}else {
					infoMap = map;
				}
			}
			afterText = sb.toString();
		}
		if(null != afterText && !"".equals(afterText)) {
			afterArr = afterText.split("\r\n");
		}
		
		Map pMap = new HashMap();
		pMap.put("path", path);
		pMap.put("url", url);
		pMap.put("beforeText", beforeText);
		pMap.put("afterText", afterText);
		
		Map<String, Object> musicMap = musicService.fileNameChange(path, afterArr, "", mode);
		List<Map> imgList = musicService.fileImgList(path, CLASS_PATH);
		model.addAllAttributes(pMap);
		model.addAttribute("musicMap", musicMap);
		model.addAttribute("infoMap", infoMap);
		model.addAttribute("imgList", imgList);
		
		return "music";
	}
	
	
	/**
	 * ajax 호출
	 * @param path
	 * @param req
	 * @param res
	 * @param multipartHttpServletRequest
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@SuppressWarnings({ "static-access", "rawtypes" })
	@RequestMapping(value={"/music/ajax/{path}"})
	public @ResponseBody String ajaxContoller(@PathVariable String path, final HttpServletRequest req, HttpServletResponse res, 
			MultipartHttpServletRequest multipartHttpServletRequest, ModelMap model) throws Exception {
		
		String coverPath = "";
		String fileDataPath = "";
		String CLASS_PATH = req.getSession().getServletContext().getRealPath("/");
		
		//메인이미지DIV로 드래그 시 처리
		if("dropImg".equals(path)) {
			//기존 main-Cover 파일 삭제
			File file = new File(CLASS_PATH + "Tmp");
			if(file != null && file.isDirectory()) {
				File[] fileList = file.listFiles();
				for(File f : fileList) {
					String fName = f.getName();
					if(fName.startsWith("main-Cover") && f.isFile()) {
						f.delete();
					}
				}
			}
			
			Enumeration enu = req.getParameterNames();
			while(enu.hasMoreElements()) {
				String key = (String)enu.nextElement();
				if(key.equals("fileDataPath")) {
					fileDataPath = req.getParameter(key).trim();
					fileDataPath = (fileDataPath.indexOf("/") == 0) ? fileDataPath.substring(1) : fileDataPath;
				}
			}
			
			if(fileDataPath.equals("")) {
				//이미지 드래그 앤 드롭 처리
				Iterator iter = multipartHttpServletRequest.getFileNames();
				while(iter.hasNext()) {
					MultipartFile mFile = multipartHttpServletRequest.getFile((String)iter.next());
					coverPath = musicService.parsePath(CLASS_PATH, mFile.getOriginalFilename(), "main-Cover");
					if(!"".equals(coverPath)) {
						mFile.transferTo(new File(coverPath));
					}
					System.out.println("coverPath ==> " + coverPath);
				}
			
			}else {
				//이미지 클릭 시 처리
				String targetPath = musicService.parsePath(CLASS_PATH, fileDataPath, "");
				coverPath = musicService.parsePath(CLASS_PATH, fileDataPath, "main-Cover");
				musicService.fileCopy(targetPath, coverPath);
			}
			model.addAttribute("message", "success");
			 
		}else if("test".equals(path)) {
			String filePath = req.getParameter("filePath");
			File file = new File(filePath);
			File[] fileList = file.listFiles();
			Arrays.sort(fileList, new AlnumCompare());	//숫자를 고려한 파일정렬(윈도우 탐색기 정렬)
			
			if(null != file && file.exists()) {
				Mp3File mp3file = new Mp3File(fileList[0].getPath());
				if(mp3file.hasId3v2Tag()) {
					ID3v2 tag = mp3file.getId3v2Tag();
					byte albumCoverData[] = tag.getAlbumImage();
					String fileExt = "";
					if(null != albumCoverData) {
						String mimeType = tag.getAlbumImageMimeType();
						fileExt = mp3util.mimeTypeConvert(mimeType);
						String classpath = req.getSession().getServletContext().getRealPath("/");
						File mkdir = new File(classpath + File.separator + "Tmp");
						if(mkdir.exists() && mkdir.isDirectory()) {
							File[] listFile = mkdir.listFiles();
							if(listFile.length > 0) {
								for(File f : listFile) {
									f.delete();
								}
							}
						}else {
							mkdir.mkdir();
						}
						coverPath = classpath + File.separator + "Tmp" + File.separator + "ori-Cover" + fileExt;
						RandomAccessFile raf = new RandomAccessFile(coverPath, "rw");
						raf.write(albumCoverData);
						raf.close();
					}
					
					if(new File(coverPath).exists() && new File(coverPath).isFile()) {
						Image img = new ImageIcon(coverPath).getImage();
						model.addAttribute("coverSize", img.getWidth(null) + "x" + img.getHeight(null));
						model.addAttribute("coverCapacity", mp3util.getDataUnit(new File(coverPath).length()));
						model.addAttribute("coverPath", "ori-Cover" + fileExt);
					}
				}
			}
		}
		return new ObjectMapper().writeValueAsString(model);
	}
	
	 
}